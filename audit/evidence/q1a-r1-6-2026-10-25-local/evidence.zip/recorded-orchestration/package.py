from pathlib import Path
import json,hashlib,subprocess,os,platform,tarfile,io,re,shutil,zipfile
r=Path('/Users/splswrd/work/agent-factory');t=Path('/private/tmp/af-r16');o=r/'audit/evidence/q1a-r1-6-2026-10-25-local';stage=t/'package';stage.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env)
report='docs/audits/remediation-q1a-r1-6-2026-10-25.md';shutil.copy2(r/report,o/'report.md')
new=git('ls-files','--others','--exclude-standard','setup',report).decode().splitlines();patch=git('diff','--binary','HEAD','--','setup')
for n in new:
 result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=r,env=env,stdout=subprocess.PIPE);assert result.returncode==1;patch+=result.stdout
(o/'full-local.patch').write_bytes(patch);(o/'new-files.json').write_text(json.dumps([{'path':n,'sha256':sha(r/n)} for n in new],indent=2)+'\n')
with tarfile.open(o/'new-files.tar','w',format=tarfile.PAX_FORMAT) as archive:
 for n in sorted(new):
  data=(r/n).read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
basepaths=git('diff','--name-only','b888082167b5edc50977a6dcda997b40e962da8d','HEAD').decode().splitlines();(t/'base-delta.json').write_text(json.dumps([{'path':n,'sha256':sha(r/n)} for n in basepaths],indent=2)+'\n')
initial=json.loads((t/'initial.json').read_text());commands=json.loads((t/'final-validation/commands.json').read_text());assert len(commands)==5 and all(x['exit_code']==0 for x in commands)
identity={'base_commit':initial['head'],'base_tree':initial['tree'],'audited_base_commit':'b888082167b5edc50977a6dcda997b40e962da8d','audited_base_tree':'9ed7b7e09eed8e80e099dc38578a9265ef634963','branch':initial['branch'],'owner_layer':{'status':initial['status'],'changes':[],'staged_patch':'logs/staged.patch','unstaged_patch':'logs/unstaged.patch'},'tested_commit':None,'tested_tree_identity':'sha256-manifest:'+sha(o/'tested-files.sha256'),'tested_manifest_sha256':sha(o/'tested-files.sha256'),'tested_files':138,'patch_sha256':sha(o/'full-local.patch'),'new_files_tar_sha256':sha(o/'new-files.tar'),'report_sha256':sha(o/'report.md'),'node':(t/'final-validation/node.log').read_text().strip(),'npm':(t/'final-validation/npm.log').read_text().strip(),'os':platform.platform(),'arch':platform.machine(),'uid':os.getuid(),'initial_index_sha256':initial['index_sha256'],'validation_commands':commands,'audit_harness_commands':json.loads((t/'audit-harness-commands.json').read_text()),'reconstruction':'git archive actual base; empty owner layer; git apply full-local.patch without index; verify tested-file/new-file hashes and deletions. New files already in full patch; tar is redundant. Packaging is separate from tested-code manifest.','exclusions':['node_modules','dist','.git','audit/report/packaging','temporary outputs/secrets'],'production_status':'OPEN','real_host_qualification':'NOT RUN','agent_commits_push_branches_worktrees_pr_release_deploy':False}
(o/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
# Check final workspace still equals exactly tested bytes and original index/HEAD.
for line in (o/'tested-files.sha256').read_text().splitlines():
 h,n=line.split('  ',1);assert sha(r/n)==sha(t/'fixed'/n)==h,n
assert git('rev-parse','HEAD').decode().strip()==initial['head'];assert git('branch','--show-current').decode().strip()==initial['branch'];assert sha(r/'.git/index')==initial['index_sha256']
(t/'final-repository-state.json').write_text(json.dumps({'head':initial['head'],'branch':initial['branch'],'index_sha256':sha(r/'.git/index'),'head_unchanged':True,'branch_unchanged':True,'index_bytes_unchanged':True,'owner_layer_empty':True,'status':git('status','--porcelain=v1').decode(),'no_agent_commit_push_branch_worktree_pr_release_deploy':True},indent=2)+'\n')
log=(t/'final-validation/tests.log').read_text();assert 'ℹ tests 397' in log and 'ℹ pass 397' in log and 'ℹ fail 0' in log
names=[re.sub(r' \([0-9.]+ms\)$','',l[2:]) for l in log.splitlines() if l.startswith('✔ ')]
for tag,name in [('R16_REAL_COMMAND','real-commands'),('R16_REFUSAL','grammar-refusals'),('R16_PROBE_CONTROL','probe-controls'),('R14_FAULT','retained-r14-faults'),('R14_CRASH','retained-r14-crashes'),('R14_RECOVERY_FAULT','retained-recovery-faults'),('R15_DOCKER_FAULT','retained-r15-docker-faults'),('R15_DOCKER_CRASH','retained-r15-docker-crashes')]:
 rows=[json.loads(l.split(' ',1)[1]) for l in log.splitlines() if l.startswith(tag+' ')];(t/(name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
acceptance=[]
for i in range(1,13):
 id=f'W{i:02d}';selected=[n for n in names if n.startswith(id+' ') or id in n.split(' ')[0]]
 if id=='W11':selected += [n for n in names if n.startswith(('U02 ','V03 '))]
 if id=='W12':selected=['All previous 364 assertions unchanged and pass in full 397-test log','33 frozen comparison assertions PASS','reconstruction-before/after and final reconstruction match manifest','final-repository-state index/head/branch unchanged']
 assert selected,id
 acceptance.append({'id':id,'finding':'R15-F01' if i<12 else 'regression/evidence','status':'PASS','scope':'local only','assertions':selected,'source':'setup/tests/integration/q1a-r16-commands.test.ts' if i<12 else 'all retained tests + packaging','log':'logs/final-validation/tests.log'})
(t/'acceptance-matrix.json').write_text(json.dumps(acceptance,indent=2)+'\n')
# Preserve original three-test red layer, never silently replace it with fixed tests.
for n in ['setup/tests/helpers/r16-commands.ts','setup/tests/integration/q1a-r16-commands.test.ts']:
 target=stage/'red-layer'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(t/'red'/n,target)
shutil.copytree(t/'runners',stage/'runners',dirs_exist_ok=True);shutil.copytree(t/'r15-frozen/inputs',stage/'inputs',dirs_exist_ok=True)
shutil.copy2(t/'input/agent-factory-r15-audit-b888082.ru.md',stage/'inputs/r15-audit.md');shutil.copy2(t/'input/copilot-r16-task.ru.md',stage/'inputs/r16-task.md')
(t/'original-runner-identity.json').write_text(json.dumps({'original_sha256':sha(t/'input/evidence/command-identity-probes.cjs'),'included_sha256':sha(t/'runners/command-identity-probes.cjs'),'unchanged':(t/'input/evidence/command-identity-probes.cjs').read_bytes()==(t/'runners/command-identity-probes.cjs').read_bytes()},indent=2)+'\n')
print(json.dumps({'files':138,'new_files':len(new),'manifest':identity['tested_manifest_sha256'],'patch':identity['patch_sha256']}))
