# R1.3 independent review evidence

Reviewed commit: `3e4e07c4ec4bf5ca898025b68520c43c5d9905e3`.
Baseline: `13f6137e414a563f9f4e152f9145245e175a2d1b`.
Runtime: Node v24.22.1, npm 11.9.0.

The two Russian Markdown files in the archive root contain the findings and next Copilot task. `review-metadata.json` pins source identity, inputs and command results. Source files were not edited during review.

## Reproduction

Use an isolated checkout of each named commit. No live host, credentials, sudo, Docker daemon or provider calls are needed. The fixtures use temporary directories and injected adapters. The existing repository suite includes a local child-process interruption test.

From each checkout:

```bash
node --version
npm --version
npm --prefix setup ci --ignore-scripts --no-audit --no-fund
npm --prefix setup run build --silent
```

Then, from this evidence directory, set the absolute path to that built checkout:

```bash
AF_REPO=/absolute/path/to/checkout
node r13-independent-probes.cjs "$AF_REPO"
node stage-compat-probes.cjs "$AF_REPO"
```

For the reviewed commit also run:

```bash
node lifecycle-controls.cjs "$AF_REPO"
node s06-noop-probe.cjs "$AF_REPO"
npm --prefix "$AF_REPO/setup" run typecheck --silent
npm --prefix "$AF_REPO/setup" run test --silent
```

The independent runner must produce C01 through C12 and a final META record. Its 45-second deadline and completion guard prevent an incomplete async run from being mistaken for complete evidence. `harness_ok: true` means the scenario was executed and measured, NOT that the product is correct. Compare outcomes with the audit and implementation acceptance criteria. On a corrected release, several recorded outcomes must change; do not encode known defects as passing expectations.

UUIDs, temporary paths, state hashes and wall-clock metadata vary between runs. Compare semantic results and proof relationships, not raw JSONL bytes. The injected gate clock is intentionally fixed so baseline/fixed comparisons have identical approval-age conditions.

## Files and scope

- `r13-probes-before.jsonl` and `r13-probes-after.jsonl`: same C01…C12 runner against baseline/current. C01 uses genuine engine plan/apply/plan evidence; C02/C03 inject loss of snapshots; C04 adds schema-valid contradictory quarantine; C09 changes a manifest binding after a real injected restore write failure.
- `r13-stage-compat-before.jsonl` and `r13-stage-compat.jsonl`: actual S03/S04/S05/S07 modules through the engine, with explicit fake prerequisites/adapters. S05 probeCalls=0 is a defect, despite apply=0.
- `r13-lifecycle-controls.jsonl`: actual S00/S01 and S02 positive controls. A new engine in the same process is not an independent-process restart.
- `r13-s06-noop.jsonl`: actual S06 no-op control with fake process adapter and fake verified S05 prerequisite.
- `r13-tests.log`: full independently run 127-test suite. Typecheck log is empty because the successful command is silent. `r13-baseline-build.log` records the successful rebuild of baseline before the final core comparison.
- `copilot-*`: supplied evidence/report excerpts, retained separately from independent results. Copilot used Node v24.12.0; independent review used v24.22.1. The input ZIP checksum is recorded in review metadata.
- `reviewed-source-tests-docs.diff`: actual reviewed changes in setup source/tests/docs. `changed-files.txt` also includes packaging changes.
- `harness-development/`: first draft runs, before correcting C07's assumption that every gate can be approved. The expected rejection of a relogin prerequisite originally tripped a harness assertion. The final C07 measures the rejection and absence of installation effects without bypassing the gate. These draft logs are not final acceptance results.

C12 deliberately uses a synthetic but internally consistent writer-API event chain to isolate primary_restored/quarantine admission. It is not evidence that SetupEngine produces that same final checkpoint layout; C01 tests that separate requirement. Fake adapter outcomes do not qualify real SSH/firewall rollback, Docker isolation, sudo policies or physical power loss.

`SHA256SUMS` covers the report, task and evidence files inside the ZIP. The ZIP's own SHA256 is separate to avoid self-reference.
