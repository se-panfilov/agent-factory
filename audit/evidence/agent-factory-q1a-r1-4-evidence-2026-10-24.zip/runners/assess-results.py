#!/usr/bin/env python3
import json,pathlib,re,sys
root=pathlib.Path(sys.argv[1]).resolve()
def rows(label):
 data=[json.loads(s) for s in (root/label/'comparison.log').read_text().splitlines() if s.startswith('{')]
 return {r['id'].split('_')[0]:r for r in data if r['id']!='META'}
b=rows('clean-baseline'); f=rows('clean-fixed'); out=[]
def require(case,condition,assertion):
 if not condition: raise AssertionError(case+': '+assertion)
 out.append({'case':case,'status':'PASS','assertion':assertion})
require('C01',all(c['recover']['exit']==0 and c['retry']['exit']==0 and c['last_effect_checkpoint_after'] is not None for c in f['C01']['cases']),'Both engine-generated direct/plan-first recovery succeed, retry is idempotent and checkpoint remains')
require('C02',f['C02']['recover']['exit']==8 and f['C02']['history_preserved'],'Newer unknown manifest is rejected and preserved')
require('C03',f['C03']['recover']['exit']==8 and f['C03']['plan']['exit']==8 and f['C03']['manifest_preserved'] and not f['C03']['primary_exists'],'Manifest-only never becomes fresh')
require('C04',f['C04']['recover']['exit']==8 and f['C04']['next_apply']['exit']==8 and f['C04']['readonly_evidence_unchanged'] and f['C04']['quarantine_still_exists'],'Quarantine blocks recovery and plan/apply before evidence changes')
c=f['C05']; traces=c['traces']
require('C05',c['apply_exit']!=0 and c['inflight'] is not None and c['recover']['exit']==8 and len([r for r in traces[-1]['journal'] if r['phase']=='checkpoint'])==2,'Refresh/simulation checkpoints durable before late install exception; install stays unknown')
require('C06',f['C06']['apply_exit']!=0 and f['C06']['probe_calls']>=1 and f['C06']['recorded_status']!='verified' and not any(r['operation'].find('probe-release')>=0 and r['phase'] in ['verify','checkpoint'] for r in f['C06']['journal']),'Failed required probe is executed and never receives verified/checkpoint evidence')
c=f['C07']; r=c['resume_evidence']
require('C07',c['apply']['exit']==4 and c['apply']['code']=='operation_manual_pause' and r is not None and r['old_session']['exit']==4 and r['active_session']['exit']==0 and r['repeat']['exit']==0 and r['install_calls']==1 and r['group_calls']==1 and r['probe_calls']==1,'Clean install/group progresses to durable pause; old session blocked; active session resumes/repeats without reinstall')
require('C08',f['C08']['apply_exit']!=0 and f['C08']['rollback_calls']==1 and f['C08']['disarm_calls']==0,'Negative tailnet probe rolls back and never disarms success')
require('C09',f['C09']['recover']['exit']==8 and f['C09']['before']==f['C09']['after'],'Prepared checkpoint conflict leaves all evidence bytes/hashes untouched')
require('C10',all(c['apply']['exit']==0 and c['apply_calls']==0 for c in f['C10']['cases']),'Empty/verify-only plans never call apply')
require('C11',f['C11']['apply_exit']==4 and f['C11']['engine_cutover_calls']==0 and f['C11']['engine_stage_calls']==0,'Approved SSH/firewall input drift blocks effects')
require('C12',f['C12']['retry']['exit']==8 and f['C12']['evidence_preserved'] and f['C12']['marker_preserved'],'Synthetic legacy-exact cleanup control still rejects quarantine')
assert all(r.get('harness_ok') for r in f.values())
assert b['C04']['recover']['exit']==0 and b['C06']['probe_calls']==0 and b['C11']['engine_cutover_calls']==1
assert all(c['recover']['exit']==8 for c in b['C01']['cases'])
(root/'comparison-assertions.json').write_text(json.dumps(out,indent=2)+'\n')
log=(root/'clean-fixed/tests.log').read_text()
passed=re.findall(r'^✔ (.+?) \([\d.]+ms\)$',log,re.M)
count=int(re.search(r'^ℹ tests (\d+)$',log,re.M).group(1)); assert len(passed)==count and 'ℹ fail 0' in log
(root/'test-results.json').write_text(json.dumps({'node':(root/'clean-fixed/node.log').read_text().strip(),'passed':count,'failed':0,'tests':[{'name':name,'status':'PASS'} for name in passed]},indent=2)+'\n')
for prefix,name,expected in [('R14_FAULT ','manifest-fault-matrix.json',36),('R14_CRASH ','child-crash-matrix.json',10),('R14_RECOVERY_FAULT ','recovery-fault-matrix.json',4)]:
 values=[json.loads(line[len(prefix):]) for line in log.splitlines() if line.startswith(prefix)]
 assert len(values)==expected,(name,len(values))
 (root/name).write_text(json.dumps(values,indent=2)+'\n')
for label in ['clean-baseline','clean-fixed']:
 commands=json.loads((root/label/'commands.json').read_text()); assert len(commands)==9 and all(c['exit_code']==0 for c in commands)
print(json.dumps({'product_counterexamples':len(out),'tests_passed':count,'manifest_cases':36,'child_crash_cases':10,'recovery_fault_cases':4}))
