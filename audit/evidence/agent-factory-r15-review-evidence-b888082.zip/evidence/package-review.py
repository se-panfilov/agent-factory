#!/usr/bin/env python3
"""Package the read-only R1.5 review. Does not modify the Git repository."""
from pathlib import Path
import hashlib
import io
import json
import os
import platform
import shutil
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'r15-review'
E = OUT / 'evidence'
GIT = ROOT / 'agent-factory'
SNAP = ROOT / 'agent-factory-review-b888082'
RECON = ROOT / 'agent-factory-r15-reconstructed'
INPUT = ROOT / 'r15-input-evidence'
BASE = 'd7d141106aa50f58c8ec9ac7c3991b4d9b42e6e6'
COMMIT = 'b888082167b5edc50977a6dcda997b40e962da8d'
OLD = '2eb026527d3448fc0d455f6fe8713cba61c0d3c5'
SOURCE_FILES = ['setup/src/adapters/git.ts', 'setup/src/adapters/docker.ts',
                'setup/src/stages/application.ts', 'setup/src/stages/docker.ts',
                'setup/src/stages/access.ts']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(GIT), *args])

def put_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)

def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]

assert git('rev-parse', 'origin/master').decode().strip() == COMMIT
remote = git('ls-remote', 'origin', 'refs/heads/master').decode().strip()
assert remote.split()[0] == COMMIT, 'Remote master changed: review scope must be refreshed'
source_delta = git('diff', '--name-only', BASE, COMMIT, '--', 'setup/src').decode().splitlines()
assert sorted(source_delta) == sorted(SOURCE_FILES)
assert not git('diff', OLD, BASE, '--', 'setup', 'AGENTS.md', 'docs/automation')

package = SNAP / 'audit/evidence/q1a-r1-5-2026-10-25-local'
incoming_zip = ROOT / 'upload/evidence.zip'
assert sha(incoming_zip.read_bytes()) == '5b75e2128b3a516d28e6ef35ee6f1bb7fe78f654d5a5fc666e473c22e28702a8'
assert incoming_zip.read_bytes() == (package / 'evidence.zip').read_bytes()
assert (ROOT / 'upload/evidence.zip.sha256').read_bytes() == (package / 'evidence.zip.sha256').read_bytes()
assert (ROOT / 'upload/remediation-q1a-r1-5-2026-10-25.md').read_bytes() == (package / 'report.md').read_bytes()
with zipfile.ZipFile(incoming_zip) as z:
    assert z.testzip() is None
    sums = z.read('SHA256SUMS').decode().splitlines()
    for row in sums:
        digest, name = row.split('  ', 1)
        assert sha(z.read(name)) == digest, name
    zip_entries = len(z.infolist())

identity = json.loads((package / 'identity.json').read_text())
for filename, key in [('full-local.patch', 'patch_sha256'), ('new-files.tar', 'new_files_payload_sha256'),
                      ('report.md', 'report_sha256'), ('tested-files.sha256', 'tested_manifest_sha256')]:
    assert sha((package / filename).read_bytes()) == identity[key], filename
tested = []
for row in (package / 'tested-files.sha256').read_text().splitlines():
    digest, name = row.split('  ', 1)
    assert sha((SNAP / name).read_bytes()) == digest, ('snapshot', name)
    assert sha((RECON / name).read_bytes()) == digest, ('reconstructed', name)
    tested.append(name)
assert len(tested) == 135
tracked_setup = git('ls-tree', '-r', '--name-only', COMMIT, '--', 'setup').decode().splitlines()
assert set(tracked_setup) == set(tested), 'Tested manifest does not exactly cover tracked setup'

# Verify all tracked snapshot files, including files outside the manifest.
tracked_regular = 0
tracked_symlinks = 0
with tarfile.open(fileobj=io.BytesIO(git('archive', COMMIT))) as t:
    for m in t.getmembers():
        if m.isfile():
            assert (SNAP / m.name).read_bytes() == t.extractfile(m).read(), m.name
            tracked_regular += 1
        elif m.issym():
            assert os.readlink(SNAP / m.name) == m.linkname, m.name
            tracked_symlinks += 1

copy(incoming_zip, E / 'input/copilot-r15-evidence.zip')
copy(ROOT / 'upload/evidence.zip.sha256', E / 'input/original-evidence.zip.sha256')
copy(ROOT / 'upload/remediation-q1a-r1-5-2026-10-25.md', E / 'input/copilot-r15-report.md')
copy(package / 'identity.json', E / 'input/copilot-identity.json')
copy(package / 'tested-files.sha256', E / 'input/tested-files.sha256')
for filename in ['r15-npm-ci.log', 'r15-typecheck.log', 'r15-tests.log']:
    copy(ROOT / filename, E / 'validation' / filename)
for path in sorted((ROOT / 'r15-independent').iterdir()):
    if path.is_file():
        copy(path, E / 'comparison' / path.name)
(E / 'source').mkdir(exist_ok=True)
(E / 'source/production-diff.patch').write_bytes(git('diff', BASE, COMMIT, '--', *SOURCE_FILES))
(E / 'source/full-name-status.txt').write_bytes(git('diff', '--name-status', BASE, COMMIT))
(E / 'source/base-vs-previous-review.txt').write_bytes(git('diff', '--name-status', OLD, BASE))
for name in SOURCE_FILES + ['setup/src/adapters/process.ts']:
    copy(SNAP / name, E / 'source' / name)

markers = {}
test_log = (ROOT / 'r15-tests.log').read_text()
for line in test_log.splitlines():
    if line.startswith(('R14_', 'R15_')):
        tag, sep, data = line.partition(' ')
        if sep:
            markers.setdefault(tag, []).append(json.loads(data))
expected_counts = {'R14_FAULT': 36, 'R14_CRASH': 10, 'R14_RECOVERY_FAULT': 4,
                   'R15_DOCKER_FAULT': 10, 'R15_DOCKER_CRASH': 3}
assert {k:len(v) for k,v in markers.items()} == expected_counts
for tag, data in markers.items():
    put_json(E / 'validation' / (tag.lower() + '.json'), data)
assert 'ℹ tests 364' in test_log and 'ℹ pass 364' in test_log
assert 'ℹ fail 0' in test_log and 'ℹ skipped 0' in test_log
assertions = json.loads((ROOT / 'r15-independent/assertions.json').read_text())
assert len(assertions) == 33 and all(x['status'] == 'PASS' for x in assertions)

probe_summary = []
for file in ['command-identity.jsonl', 'command-identity-stage.jsonl']:
    data = rows(E / file)
    checks = [row for row in data if row['id'] != 'META']
    assert len(checks) == 4
    assert [r['acceptance'] for r in checks] == [True, False, False, False]
    assert all(r['manifest_schema_valid'] and r['harness_ok'] for r in checks)
    assert all(r['real_privileged_or_network_commands'] == 0 for r in checks)
    for row in checks:
        if row['mode'] == 'stage':
            assert row['result']['stage_status'] == 'verified'
        probe_summary.append({'mode': row['mode'], 'id': row['id'], 'acceptance': row['acceptance'],
                              'result': row['result'], 'children': row['local_stdout_only_node_children']})
put_json(E / 'probe-acceptance.json', probe_summary)

put_json(E / 'identity-verification.json', {
    'date': '2026-10-25', 'timezone': 'Europe/Amsterdam', 'commit': COMMIT,
    'tree': git('rev-parse', COMMIT + '^{tree}').decode().strip(), 'local_package_base': BASE,
    'previous_review': OLD, 'remote_master_read_only_result': remote,
    'input_zip_sha256': sha(incoming_zip.read_bytes()), 'input_zip_entries': zip_entries,
    'input_internal_checksums_verified': len(sums), 'package_identity_hashes_verified': True,
    'attachment_bytes_equal_master_package': True, 'tested_manifest_count': len(tested),
    'tested_manifest_sha256': sha((package / 'tested-files.sha256').read_bytes()),
    'snapshot_and_reconstructed_hashes_equal_manifest': True,
    'manifest_exactly_covers_tracked_setup': True,
    'all_snapshot_tracked_regular_files_equal_git': tracked_regular,
    'all_snapshot_tracked_symlinks_equal_git': tracked_symlinks,
    'production_delta_files': source_delta,
    'original_checkout_HEAD': git('rev-parse', 'HEAD').decode().strip(),
    'original_checkout_status': git('status', '--short').decode().splitlines(),
    'reviewer_os': platform.platform(), 'reviewer_arch': platform.machine(), 'reviewer_uid': os.getuid(),
    'reviewer_node': subprocess.check_output(['node', '--version']).decode().strip(),
    'reviewer_npm': subprocess.check_output(['npm', '--version'], stderr=subprocess.DEVNULL).decode().strip(),
    'product_code_edited_by_reviewer': False,
    'note': 'Read-only Git inspection; isolated git archive snapshots. No commits, branches, push, PR or deploy.'
})
put_json(E / 'validation-summary.json', {
    'npm_ci_exit': 0, 'typecheck_exit': 0, 'tests_exit': 0, 'test_count': 364, 'test_pass': 364,
    'test_fail': 0, 'test_skip': 0, 'comparison_product_assertions_pass': 33,
    'fault_and_crash_rows': expected_counts,
    'new_probe_product_acceptance_per_mode': {'adapter': '1 PASS, 3 FAIL', 'stage': '1 PASS, 3 FAIL'},
    'new_probe_harness_exit_per_mode': {'adapter': 0, 'stage': 0},
    'new_probe_stdout_only_children_total': sum(r['children'] for r in probe_summary),
    'suite_commands': ['npm --prefix setup ci --ignore-scripts --no-audit --no-fund',
                       'npm --prefix setup run typecheck --silent', 'npm --prefix setup run test --silent'],
    'probe_commands': ['node evidence/command-identity-probes.cjs /path/to/compiled-snapshot adapter',
                       'node evidence/command-identity-probes.cjs /path/to/compiled-snapshot stage'],
    'not_run': ['real sudo/apt/systemd/SSH/UFW', 'Docker daemon/cgroups', 'VM/VPS qualification',
                'OAuth/provider/model calls', 'GitHub writes', 'product deploy', 'physical power loss'],
    'limits': 'Stage probe uses synthetic archive/checkout/receipt with real content and process adapters; UID0 test environment is not owner-session deployment qualification.'
})

checksum = E / 'SHA256SUMS'
all_files = sorted(p for p in OUT.rglob('*') if p.is_file() and p != checksum
                   and p.parent != OUT)  # deliverable root files are added explicitly below
all_files += [OUT / 'agent-factory-r15-audit-b888082.ru.md', OUT / 'copilot-r16-task.ru.md', OUT / 'README.md']
all_files = sorted(set(all_files))
checksum.write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(OUT).as_posix()}\n' for p in all_files))
archive = OUT / 'agent-factory-r15-review-evidence-b888082.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(all_files + [checksum]):
        info = zipfile.ZipInfo(p.relative_to(OUT).as_posix(), date_time=(2026,10,25,12,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, p.read_bytes())
archive_hash = sha(archive.read_bytes())
(OUT / (archive.name + '.sha256')).write_text(f'{archive_hash}  {archive.name}\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in z.read('evidence/SHA256SUMS').decode().splitlines():
        digest, name = row.split('  ', 1)
        assert sha(z.read(name)) == digest, name
    archive_entries = len(z.infolist())
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'entries': archive_entries, 'sha256': archive_hash,
                  'tracked_snapshot_files_checked': tracked_regular,
                  'tested_manifest_entries': len(tested), 'input_checksums': len(sums),
                  'tests': 364, 'comparison_assertions': 33,
                  'new_probes': '3 product FAIL + 1 PASS in each mode; all harness executions complete'}, indent=2))
