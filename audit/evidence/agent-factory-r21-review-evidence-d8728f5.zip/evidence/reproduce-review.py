"""Reproduce the fixed-version R2.1 review locally; no branches/index/host mutations."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True, type=Path)
p.add_argument('--work', required=True, type=Path)
a = p.parse_args()
repo = a.repo.resolve()
work = a.work.resolve()
package = Path(__file__).resolve().parent.parent
incoming = package / 'incoming'
assert not work.exists() or not any(work.iterdir()), 'Work directory must be empty.'
work.mkdir(parents=True, exist_ok=True)
assert subprocess.check_output(['node', '--version'], text=True).startswith('v24.')
env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}
commands = []

def run(name, argv, cwd=work, expected=0):
    start = time.monotonic()
    logfile = work / 'logs' / name
    logfile.parent.mkdir(parents=True, exist_ok=True)
    with logfile.open('w') as stream:
        result = subprocess.run([str(x) for x in argv], cwd=cwd, env=env,
                                stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    commands.append({'argv': [str(x) for x in argv], 'cwd': str(cwd),
                     'exit_code': result.returncode, 'expected_exit': expected,
                     'elapsed_seconds': round(time.monotonic()-start, 3), 'log': str(logfile)})
    (work / 'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert result.returncode == expected, f'{name}: {result.returncode}, expected {expected}'

def archive(commit, name):
    destination = work / name
    destination.mkdir()
    raw = subprocess.check_output(['git', 'archive', commit], cwd=repo, env=env)
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        stream.extractall(destination, filter='data')
    return destination

baseline = archive('ca6d0b6f2a75f3c97a80468bbc2bdcbe2db7a4ff', 'baseline')
historical = archive('b888082167b5edc50977a6dcda997b40e962da8d', 'historical-r15')
fixed = work / 'fixed'
run('reconstruct.log', ['python3', incoming/'runners/reconstruct.py', '--repo', repo,
                        '--bundle', incoming/'bundle', '--output', fixed])
run('validation.log', ['python3', incoming/'runners/validate.py', '--checkout', fixed,
                       '--bundle', incoming/'bundle', '--logs', work/'validation'])
for label, tree in [('baseline', baseline), ('historical-r15', historical)]:
    run(label+'-ci.log', ['npm', '--prefix', 'setup', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], tree)
    run(label+'-build.log', ['npm', '--prefix', 'setup', 'run', 'build', '--silent'], tree)
run('comparisons.log', ['python3', incoming/'runners/measure-r21.py', '--baseline', baseline,
                       '--fixed', fixed, '--historical-command-baseline', historical,
                       '--inputs', incoming/'inputs', '--logs', work/'comparisons'])
for label, tree in [('baseline', baseline), ('fixed', fixed)]:
    logname = 'access-'+label+'.jsonl'
    run(logname, ['node', package/'evidence/access-continuation-probes.cjs', tree])
    run('access-'+label+'-observed.json', ['python3', package/'evidence/check-access-continuation.py',
                                         work/'logs'/logname, '--expect', 'observed-r21'])
run('access-desired-red.json', ['python3', package/'evidence/check-access-continuation.py',
                                work/'logs/access-fixed.jsonl', '--expect', 'fixed'], expected=1)
for line in (incoming/'bundle/tested-files.sha256').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert hashlib.sha256((fixed/name).read_bytes()).hexdigest() == digest, name
print('Review reproduced: old protections pass; S03 desired product oracle has 10 expected failures.')
