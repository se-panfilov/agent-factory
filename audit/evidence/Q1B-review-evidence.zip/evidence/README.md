# Reviewer evidence Q1B

Verdict CHANGES_REQUIRED_LOCAL, exact head2026fe1ebf8348fa4729e6e76bbec9404ee2ac71.

Run probes with Node24 against an independently built snapshot:

```
node group-census-probe.cjs /absolute/source
node spawn-sync-probe.cjs /absolute/source
python3 check-review-probes.py .
```

The last command verifies preserved negative evidence, not acceptance. group-census is environment-dependent; the recorded namespace mismatch is not qualification of normal Ubuntu. Children are owned finite Node fixtures; no daemon, privileged or network effects. Sources in this bundle are reviewed copies, not fixes.

Attempt1 logs contain archive mode0664 preparation error; never treat all452 failures as product regressions. Attempt2 stderr is preserved; its detailed temporary logs were lost between continuations and its final count is unknown. No successful full independent inherited run is claimed. See Q1B-audit.md for exact limitations and next task.

No commits/push/branches/worktree/PR/merge/tag/release/deploy/staging/index changes.
