from pathlib import Path
import shutil,json,hashlib,zipfile,subprocess,os
r=Path('/Users/splswrd/work/agent-factory');t=Path('/private/tmp/af-r16');o=r/'audit/evidence/q1a-r1-6-2026-10-25-local';stage=t/'package'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((t/'final-reconstruction.json').read_text())['manifest_sha256']==sha(o/'tested-files.sha256')
assert json.loads((t/'reconstruction-after.json').read_text())['source_and_reconstructed_hashes_unchanged']
assert len(json.loads((t/'comparison-assertions.json').read_text()))==33
logs=stage/'logs';logs.mkdir(exist_ok=True)
for p in t.iterdir():
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.patch','.txt']:shutil.copy2(p,logs/p.name)
for name in ['final-validation','frozen-comparisons']:shutil.copytree(t/name,logs/name,dirs_exist_ok=True)
# Portable runners are already staged. Keep actual orchestration scripts as recorded execution inputs too.
recorded=stage/'recorded-orchestration';recorded.mkdir(exist_ok=True)
for name in ['validation.py','run-comparisons.py','reconstruct-code.py','package.py','finalize.py']:shutil.copy2(t/name,recorded/name)
bundle=stage/'bundle';bundle.mkdir(exist_ok=True)
for name in ['identity.json','report.md','full-local.patch','new-files.tar','new-files.json','tested-files.sha256','deletions.json']:shutil.copy2(o/name,bundle/name)
shutil.copy2(t/'README.md',stage/'README.md');shutil.copy2(t/'README.md',o/'README.md')
files=sorted(p for p in stage.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(stage/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(stage))+'\n' for p in files))
zpath=o/'evidence.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(p for p in stage.rglob('*') if p.is_file()):
  info=zipfile.ZipInfo(str(p.relative_to(stage)),(2026,10,25,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes(),compresslevel=9)
(o/'evidence.zip.sha256').write_text(sha(zpath)+'  evidence.zip\n')
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
 assert z.read('bundle/report.md')==(o/'report.md').read_bytes()==(r/'docs/audits/remediation-q1a-r1-6-2026-10-25.md').read_bytes()
 assert z.read('bundle/full-local.patch')==(o/'full-local.patch').read_bytes()
 assert z.read('runners/command-identity-probes.cjs')==(t/'input/evidence/command-identity-probes.cjs').read_bytes()
ident=json.loads((o/'identity.json').read_text());assert sha(o/'full-local.patch')==ident['patch_sha256'];assert sha(o/'report.md')==ident['report_sha256'];assert sha(r/'.git/index')==ident['initial_index_sha256']
for l in (o/'tested-files.sha256').read_text().splitlines():
 h,n=l.split('  ',1);assert sha(r/n)==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip()==ident['base_commit']
print(json.dumps({'zip':str(zpath),'sha256':sha(zpath),'bytes':zpath.stat().st_size,'entries':len(files)+1,'report_bytes_match':True,'runner_original_bytes_match':True,'index_unchanged':True,'final_tested_manifest':ident['tested_manifest_sha256']},indent=2))
