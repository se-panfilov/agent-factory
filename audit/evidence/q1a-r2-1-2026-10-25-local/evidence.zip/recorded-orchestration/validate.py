import subprocess,json,os,time,sys
from pathlib import Path
root=Path(sys.argv[1]);logs=Path(sys.argv[2]);logs.mkdir(exist_ok=True,parents=True);env={**os.environ,'PATH':'/Users/splswrd/.nvm/versions/node/v24.12.0/bin:'+os.environ['PATH']};rows=[]
for name,argv in [('node',['node','--version']),('npm',['npm','--version']),('ci',['npm','--prefix','setup','ci','--ignore-scripts','--no-audit','--no-fund']),('typecheck',['npm','--prefix','setup','run','typecheck','--silent']),('tests',['npm','--prefix','setup','run','test','--silent'])]:
 start=time.time()
 with open(logs/(name+'.log'),'w') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'argv':argv,'cwd':str(root),'exit_code':r.returncode,'log':name+'.log','elapsed_seconds':round(time.time()-start,3)});(logs/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
