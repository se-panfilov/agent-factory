const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { createHash } = require('node:crypto');
const repo = process.argv[2] || process.cwd();
const from = name => require(path.join(repo, 'setup/dist/src', name));
const { NodeFilesystemAdapter } = from('adapters/filesystem.js');
const { initConfig, stableStringify } = from('core/config.js');
const { loadState, initState, saveState, appendEvent, inspectJournalEvidence, stateHash, readStateCommitManifest } = from('core/state.js');
const { acquireLock, requestCancel } = from('core/lock.js');
const { SetupEngine } = from('core/engine.js');
const { createRegistry } = from('core/plan.js');
const { createSystemStage } = from('stages/system.js');
const { createAuthStage } = from('stages/auth.js');
const { createPreflightStage } = from('stages/preflight.js');

const f = new NodeFilesystemAdapter();
let instant = new Date('2026-10-23T10:00:00Z');
const clock = { now: () => new Date(instant) };
const proc = {
  pid: () => process.pid, uid: () => 1000, username: () => 'factory',
  bootId: async () => 'f324dcd7-4035-4430-ab39-ce31f9e396bf',
  machineIdHash: async () => 'a'.repeat(64), processStartTicks: async () => 1,
  isPidAlive: () => true,
  runCommand: async () => { throw new Error('No real commands permitted in review probes'); }
};
let root;
const emit = (id, result) => console.log(JSON.stringify({ id, ...result }));
function stage(id, dependencies = [], overrides = {}) {
  return {
    id, dependencies, supportedProfiles: ['supervised', 'service'], optional: false, requiredCapabilities: [],
    observe: async () => ({ stageId: id, status: 'verified', checks: {}, versions: {}, observedAt: clock.now().toISOString() }),
    plan: () => ({ stageId: id, optional: false, requiredCapabilities: [], operations: [], requiredGates: [] }),
    apply: async () => [], verify: async () => [], recover: async () => [], ...overrides
  };
}
const engine = (stages, extra = {}) => new SetupEngine({ fsAdapter: f, processAdapter: proc, clock, ...extra }, createRegistry(stages));
async function fixture(name, selected = ['S01']) {
  instant = new Date('2026-10-23T10:00:00Z');
  const dir = path.join(root, name);
  await fs.mkdir(dir, { recursive: true });
  const configPath = path.join(dir, 'config.json');
  const c = await initConfig(f, configPath, 'supervised', 'factory');
  for (const [key, suffix] of Object.entries({ setup_state_dir: 'setup-state', setup_cache_dir: 'cache', setup_bin_dir: 'bin', setup_node_dir: 'node', application_dir: 'app', application_state_dir: 'app/state', application_auth_dir: 'app/auth', application_work_dir: 'app/work' })) c.paths[key] = path.join(dir, suffix);
  c.version_lock_path = path.join(dir, 'versions.lock.json');
  c.release.archive_path = path.join(dir, 'release.tar.xz');
  c.selected_stages = selected;
  await fs.writeFile(configPath, JSON.stringify(c));
  await fs.mkdir(c.paths.setup_state_dir, { recursive: true });
  return { c, configPath, dir, primary: path.join(c.paths.setup_state_dir, 'state.json'), marker: path.join(c.paths.setup_state_dir, 'recovery-required.json') };
}
async function initial(c) {
  const state = await initState(f, proc, clock, c, '0.0.1');
  await saveState(f, c, state);
  return state;
}
async function expectCode(action, expected) {
  let observed;
  try { await action(); } catch (error) { observed = error.code || error.message; }
  assert.equal(observed, expected);
}

const readOnly = { initializeIfMissing: false, persistConfigDrift: false, readOnly: true };
const ioError = code => Object.assign(new Error(`injected ${code}`), { code });
const pending = id => ({ id, stage_id: 'S08', kind: 'mutate', started_at: clock.now().toISOString() });
function eventLine(sequence, code, id, stageId = 'S01') {
  const record = { sequence, at: clock.now().toISOString(), operation_id: id, stage: stageId, code, message: `${code}:test` };
  record.checksum = createHash('sha256').update(`${record.sequence}|${record.at}|${record.operation_id}|${record.stage}|${record.code}|${record.message}`).digest('hex');
  return JSON.stringify(record) + '\n';
}
async function writeJournal(x, text) {
  await fs.writeFile(path.join(x.c.paths.setup_state_dir, 'events.jsonl'), text);
}
async function readState(x) { return JSON.parse(await fs.readFile(x.primary, 'utf8')); }
function fakeApt(initiallyInstalled) {
  let installed = initiallyInstalled;
  let installCalls = 0;
  return {
    count: () => installCalls,
    adapter: {
      observe: async names => ({ metadataFresh: true, metadataUpdatedAt: clock.now().toISOString(), sudoAvailable: true, dpkgAuditClean: true, dpkgAuditOutput: '', rebootRequired: false, packages: names.map(name => ({ name, installedVersion: installed ? '1.0' : null, candidateVersion: '1.0' })) }),
      refreshMetadata: async () => { throw new Error('unexpected refresh'); },
      simulateInstall: async () => {},
      installPinned: async () => { installed = true; installCalls++; }
    }
  };
}

// Review probes assert observed behavior at b0bc219. Defect assertions must be
// inverted into fail-closed regression expectations when implementing a fix.
const op = (id, kind = 'mutate') => ({id, stageId:'S01', kind, resourceId:`res-${id}`,risk:'low',gateIds:[],preconditions:[],sideEffects:kind==='mutate'?['temp fixture only']:[],timeoutSec:10,retryable:false});
const receipt = (o, overrides={}) => ({operationId:o.id,stageId:o.stageId,resourceId:o.resourceId,observedAt:clock.now().toISOString(),checks:{verified:true},versions:{},artifacts:[],...overrides});
const plannedStage = (ops, apply) => stage('S01', [], {plan:()=>({stageId:'S01',optional:false,requiredCapabilities:[],operations:ops,requiredGates:[]}),apply});
async function applyOnce(e,x) {
 const p=await e.run('plan',{configPath:x.configPath}); assert.equal(p.exitCode,0,JSON.stringify(p));
 const a=await e.run('apply',{configPath:x.configPath,planPath:path.join(x.c.paths.setup_state_dir,'plan.json')});
 return a;
}
async function journal(x) {const p=path.join(x.c.paths.setup_state_dir,'events.jsonl');return await f.exists(p)?(await fs.readFile(p,'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse):[];}
// Pinned review: positive expectations verify fixes; N cases assert remaining
// incorrect behavior. Runner success is not product acceptance.
async function test(id,fn){try{emit(id,{passed:true,...await fn()});}catch(e){emit(id,{passed:false,error:String(e.stack||e)});process.exitCode=1;}}
async function completeEffect(name) {
 const x=await fixture(name);const o=op('completed-op');let calls=0;
 const e=engine([plannedStage([o],async()=>{calls++;return[receipt(o)];})]);
 const a=await applyOnce(e,x);assert.equal(a.exitCode,0,JSON.stringify(a));
 const state=await readState(x);const m=await readStateCommitManifest(f,x.c);const j=await journal(x);
 assert.equal(m.last_state_hash,stateHash(state));assert.equal(m.last_effect_checkpoint.state_hash,stateHash(state));assert.equal(j.at(-1).state_hash,stateHash(state));
 return {...x,e,state,m,calls};
}
async function provenMissing(name) {
 const x=await completeEffect(name);await saveState(f,x.c,x.state);await fs.unlink(x.primary);
 assert.equal(stateHash(JSON.parse(await fs.readFile(x.primary+'.previous','utf8'))),x.m.last_effect_checkpoint.state_hash);
 return x;
}
async function prepareViaFault(name) {
 const x=await provenMissing(name);let hits=0;const faulty=Object.create(f);
 faulty.writeText=async(p,body,mode)=>{if(p.includes('state.json.tmp-')&&hits===0){hits++;throw ioError('EIO');}return f.writeText(p,body,mode);};
 const r=await engine([stage('S01')],{fsAdapter:faulty}).run('recover',{configPath:x.configPath});
 assert.equal(hits,1);assert.equal(r.exitCode,8,JSON.stringify(r));assert.equal(r.envelope.error.code,'recovery_primary_persist_failed');
 const marker=JSON.parse(await fs.readFile(x.marker,'utf8'));assert.equal(marker.recovery_commit.phase,'prepared');
 return {...x,markerRecord:marker,hits};
}
(async()=>{
 root=await fs.mkdtemp(path.join(os.tmpdir(),'af-r12-13f6137-'));
 await test('P01_stale_primary_blocked_by_manifest',async()=>{
  const x=await fixture('stale');const old=await initial(x.c);const o=op('one');const e=engine([plannedStage([o],async()=>[receipt(o)])]);
  assert.equal((await applyOnce(e,x)).exitCode,0);await fs.writeFile(x.primary,JSON.stringify(old));
  const r=await e.run('recover',{configPath:x.configPath});assert.equal(r.exitCode,8);assert.equal(r.envelope.error.code,'state_generation_mismatch');
  return {recover_exit:r.exitCode,error:r.envelope.error.code};
 });
 await test('P02_wrong_receipts_and_noop_fixed',async()=>{
  const x=await fixture('wrong');const ops=[op('one'),op('two')];const e=engine([plannedStage(ops,async()=>[receipt(op('foreign'),{stageId:'S12'})])]);
  const a=await applyOnce(e,x);assert.equal(a.exitCode,8);assert.equal(a.envelope.error.code,'stage_effect_receipt_stage_mismatch');assert.equal((await journal(x)).some(r=>r.code==='checkpoint'),false);assert.ok((await readState(x)).in_flight_operation);
  const y=await fixture('noop');let calls=0;const noop=await applyOnce(engine([plannedStage([],async()=>{calls++;return[];})]),y);assert.equal(noop.exitCode,0);assert.equal(calls,0);
  return {foreign_receipt_exit:8,no_terminal_checkpoint:true,empty_plan_exit:0,noop_apply_calls:0};
 });
 await test('P03_prepared_decision_and_typed_error_fixed',async()=>{
  const results=[];
  for(const mode of ['same','changed-previous','newer-primary']) {
   const x=await prepareViaFault('prepared-'+mode);const originalMarker=await fs.readFile(x.marker,'utf8');
   if(mode==='changed-previous')await fs.writeFile(x.primary+'.previous',JSON.stringify({...x.state,installer_version:'0.0.2'}));
   if(mode==='newer-primary')await fs.writeFile(x.primary,JSON.stringify({...x.state,in_flight_operation:pending('new-unknown')}));
   const before=await f.exists(x.primary)?await fs.readFile(x.primary,'utf8'):null;
   const r=await engine([stage('S01')]).run('recover',{configPath:x.configPath});
   assert.equal(r.exitCode,mode==='same'?0:8,JSON.stringify(r));
   if(mode!=='same') {assert.equal(await fs.readFile(x.marker,'utf8'),originalMarker);if(before!==null)assert.equal(await fs.readFile(x.primary,'utf8'),before);}
   results.push({mode,recover_exit:r.exitCode,first_fault_hits:x.hits,first_fault_code:'recovery_primary_persist_failed',decision_preserved:mode==='same'?null:true});
  }
  return {cases:results};
 });
 await test('P04_legacy_missing_primary_is_blocked',async()=>{
  const x=await fixture('legacy');const s=await initial(x.c);await saveState(f,x.c,{...s,in_flight_operation:pending('legacy-unknown')});await fs.unlink(x.primary);
  const r=await engine([stage('S01')]).run('recover',{configPath:x.configPath});assert.equal(r.exitCode,8);return {recover_exit:8,error:r.envelope.error.code};
 });
 await test('N01_old_checkpoint_overrides_newer_manifest',async()=>{
  const x=await completeEffect('new-generation');const unknown={...x.state,in_flight_operation:pending('newer-unknown-effect')};
  await saveState(f,x.c,unknown);const m=await readStateCommitManifest(f,x.c);assert.notEqual(m.last_state_hash,m.last_effect_checkpoint.state_hash);
  await fs.unlink(x.primary);
  const r=await engine([stage('S01')]).run('recover',{configPath:x.configPath});assert.equal(r.exitCode,0,JSON.stringify(r));assert.equal((await readState(x)).in_flight_operation,null);
  return {defect_reproduced:true,recover_exit:0,manifest_current_hash_differs_from_checkpoint:true,newer_generation_discarded:true,unknown_after:null,proof_generated_by_engine:true};
 });
 await test('N02_manifest_only_history_reinitialized',async()=>{
  const x=await fixture('manifest-only');const s=await initial(x.c);await saveState(f,x.c,{...s,in_flight_operation:pending('lost-primary-unknown')});
  const before=await readStateCommitManifest(f,x.c);await fs.unlink(x.primary);await fs.unlink(x.primary+'.previous');
  const e=engine([stage('S01')]);const r=await e.run('recover',{configPath:x.configPath});assert.equal(r.exitCode,0);assert.equal(r.envelope.data.scope,'fresh_installation_without_state');
  const p=await e.run('plan',{configPath:x.configPath});assert.equal(p.exitCode,0,JSON.stringify(p));const after=await readStateCommitManifest(f,x.c);assert.notEqual(before.last_state_hash,after.last_state_hash);assert.equal((await readState(x)).in_flight_operation,null);
  return {defect_reproduced:true,existing_manifest:true,recover_exit:0,recovery_scope:r.envelope.data.scope,plan_exit:0,manifest_replaced:true,unknown_after:null,scenario:'snapshot files missing, manifest remains; no journal'};
 });
 await test('N03_cleanup_ignores_new_quarantine',async()=>{
  const x=await provenMissing('cleanup-quarantine');let hits=0;const faulty=Object.create(f);
  faulty.remove=async(p,options)=>{if(p===x.marker&&hits===0){hits++;throw ioError('EIO');}return f.remove(p,options);};
  const r1=await engine([stage('S01')],{fsAdapter:faulty}).run('recover',{configPath:x.configPath});assert.equal(hits,1);assert.equal(r1.exitCode,8);assert.equal(JSON.parse(await fs.readFile(x.marker,'utf8')).recovery_commit.phase,'primary_restored');
  const q=x.primary+'.corrupt-newer';await fs.writeFile(q,JSON.stringify({...x.state,in_flight_operation:pending('quarantined-unknown')}));
  const r2=await engine([stage('S01')]).run('recover',{configPath:x.configPath});assert.equal(r2.exitCode,0,JSON.stringify(r2));assert.equal(await f.exists(x.marker),false);assert.equal(await f.exists(q),true);
  return {defect_reproduced:true,cleanup_fault_hits:hits,first_recover:r1.exitCode,second_recover:r2.exitCode,quarantine_retained_but_ignored:true,marker_removed:true};
 });
 await test('N04_plan_marker_blocks_proven_recovery',async()=>{
  const direct=await provenMissing('direct-recover');const a=await engine([stage('S01')]).run('recover',{configPath:direct.configPath});assert.equal(a.exitCode,0);
  const x=await provenMissing('plan-first-recover');const e=engine([stage('S01')]);const p=await e.run('plan',{configPath:x.configPath});assert.equal(p.exitCode,8);const marker=JSON.parse(await fs.readFile(x.marker,'utf8'));
  const r=await e.run('recover',{configPath:x.configPath});assert.equal(r.exitCode,8);assert.equal(r.envelope.error.code,'recovery_unresolved');
  return {defect_reproduced:true,direct_recover_exit:0,plan_first_exit:8,marker_reason:marker.reason,recover_after_plan_exit:r.exitCode,proof_generated_by_engine:true};
 });
 await test('N05_S02_progress_not_durable_between_operations',async()=>{
  const x=await fixture('apt-progress',['S02']);let refreshCalls=0,simulateCalls=0,installCalls=0;const traces=[];
  const apt={observe:async names=>({metadataFresh:refreshCalls>0,metadataUpdatedAt:clock.now().toISOString(),sudoAvailable:true,dpkgAuditClean:true,dpkgAuditOutput:'',rebootRequired:false,packages:names.map(name=>({name,installedVersion:null,candidateVersion:'1.0'}))}),
  refreshMetadata:async()=>{traces.push({at:'refresh',journal:(await journal(x)).map(r=>[r.operation_id,r.code])});refreshCalls++;},
  simulateInstall:async()=>{traces.push({at:'simulate',journal:(await journal(x)).map(r=>[r.operation_id,r.code])});simulateCalls++;},
  installPinned:async()=>{traces.push({at:'install',journal:(await journal(x)).map(r=>[r.operation_id,r.code])});installCalls++;throw ioError('EIO');}};
  const e=engine([stage('S01'),createSystemStage(apt)]);const p=await e.run('plan',{configPath:x.configPath});assert.equal(p.exitCode,0,JSON.stringify(p));
  for(const g of p.envelope.data.required_approvals){const a=await e.run('gate-approve',{configPath:x.configPath,gateId:g.id,planHash:p.envelope.plan_hash});assert.equal(a.exitCode,0,JSON.stringify(a));}
  const a=await e.run('apply',{configPath:x.configPath,planPath:path.join(x.c.paths.setup_state_dir,'plan.json')});assert.notEqual(a.exitCode,0);
  const records=await journal(x);assert.equal(refreshCalls,1);assert.equal(simulateCalls,1);assert.equal(installCalls,1);assert.equal(records.filter(r=>r.code==='effect').length,0);assert.equal(records.filter(r=>r.code==='intent').length,3);
  return {defect_reproduced:true,apply_exit:a.exitCode,completed_refresh:1,completed_simulate:1,failed_install:1,journal:records.map(r=>[r.operation_id,r.code]),traces,uncertainty_preserved:true};
 });
 emit('META',{node:process.version,repo,temporary_root:root,real_commands:0});
})().catch(e=>{console.error(e.stack||e);process.exitCode=1;});
