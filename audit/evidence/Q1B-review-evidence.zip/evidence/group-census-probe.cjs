const path=require('path'),fs=require('fs/promises'),os=require('os');
const {NodeProcessAdapter}=require(path.join(process.argv[2],'setup/dist/src/adapters/process.js'));
(async()=>{const root=await fs.mkdtemp(path.join(os.tmpdir(),'q1b-review-census-'));const proof=path.join(root,'child.json');
const grand=`const fs=require('fs'); setTimeout(()=>fs.writeFileSync(${JSON.stringify(proof)},JSON.stringify({pid:process.pid,at:Date.now()})),700);setTimeout(()=>process.exit(0),1100)`;
const source=`require('child_process').spawn(process.execPath,['-e',${JSON.stringify(grand)}],{stdio:'ignore'});setTimeout(()=>process.exit(0),150)`;
const begin=Date.now(); const r=await new NodeProcessAdapter().runCommand({policy:'interruptible',binary:process.execPath,args:['-e',source],timeoutMs:2000,maxOutputBytes:256});const returnedAt=Date.now();
await new Promise(resolve=>setTimeout(resolve,1250));const late=await fs.readFile(proof,'utf8').then(JSON.parse).catch(()=>null);
console.log(JSON.stringify({id:'Q1B-REVIEW-CENSUS',actualUid:process.getuid(),node:process.version,selfPid:process.pid,selfProc:await fs.readFile('/proc/self/stat','utf8'),duration:returnedAt-begin,result:r,lateWrite:late,writeAfterReturn:late&&late.at>returnedAt}));})();
