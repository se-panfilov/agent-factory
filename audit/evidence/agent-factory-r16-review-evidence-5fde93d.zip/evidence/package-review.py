#!/usr/bin/env python3
"""Read-only Git review verification and evidence packaging; no product writes."""
from pathlib import Path
import hashlib
import io
import json
import os
import platform
import shutil
import subprocess
import tarfile
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'r16-review';E=OUT/'evidence';GIT=ROOT/'agent-factory'
SNAP=ROOT/'agent-factory-review-5fde93d';RECON=ROOT/'agent-factory-r16-reconstructed'
COMMIT='5fde93d2c470171039698c35478c020085ef66ff'
BASE='420e5456d3e05b1c4f9b7202cacebb82baaf61eb'
OLD='b888082167b5edc50977a6dcda997b40e962da8d'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(GIT),*args])
def save(name,data):
 p=E/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def copy(src,name):
 p=E/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s]

remote=git('ls-remote','origin','refs/heads/master').decode().strip()
assert remote.split()[0]==COMMIT,'Remote master changed; refresh review scope'
assert git('rev-parse','origin/master').decode().strip()==COMMIT
assert not git('diff',OLD,BASE,'--','setup','AGENTS.md','docs/automation')
delta=git('diff','--name-only',BASE,COMMIT,'--','setup/src').decode().splitlines()
assert delta==['setup/src/adapters/git.ts']
published=SNAP/'audit/evidence/q1a-r1-6-2026-10-25-local'
bundle=ROOT/'r16-input-evidence/bundle'
uploads={
 'copilot-r16-report.md':ROOT/'upload/remediation-q1a-r1-6-2026-10-25(1).md',
 'full-local.patch':ROOT/'upload/full-local(1).patch',
 'copilot-r16-evidence.zip':ROOT/'upload/evidence(2).zip',
 'original-evidence.zip.sha256':ROOT/'upload/evidence.zip(2).sha256'}
for dest,src in uploads.items():copy(src,Path('input')/dest)
for dest,srcname in [('copilot-r16-report.md','report.md'),('full-local.patch','full-local.patch'),
                     ('copilot-r16-evidence.zip','evidence.zip'),('original-evidence.zip.sha256','evidence.zip.sha256')]:
 assert uploads[dest].read_bytes()==(published/srcname).read_bytes(),dest
zipbytes=uploads['copilot-r16-evidence.zip'].read_bytes()
assert sha(zipbytes)=='13c9d74371d0e9fe9203e221ccd838af4d3d0f37ed4ac9ae8013088147bb5930'
with zipfile.ZipFile(io.BytesIO(zipbytes)) as z:
 assert z.testzip() is None
 sums=z.read('SHA256SUMS').decode().splitlines()
 for s in sums:
  digest,name=s.split('  ',1);assert sha(z.read(name))==digest,name
 input_entries=len(z.infolist())
identity=json.loads((bundle/'identity.json').read_text())
for name,key in [('full-local.patch','patch_sha256'),('new-files.tar','new_files_tar_sha256'),
                 ('report.md','report_sha256'),('tested-files.sha256','tested_manifest_sha256')]:
 assert sha((bundle/name).read_bytes())==identity[key],name
 assert (bundle/name).read_bytes()==(published/name).read_bytes(),name
copy(bundle/'identity.json',Path('input/copilot-identity.json'))
copy(bundle/'tested-files.sha256',Path('input/tested-files.sha256'))
tested=[]
for s in (bundle/'tested-files.sha256').read_text().splitlines():
 digest,name=s.split('  ',1)
 for folder in [SNAP,RECON]:assert sha((folder/name).read_bytes())==digest,(folder,name)
 tested.append(name)
assert len(tested)==138
assert set(tested)==set(git('ls-tree','-r','--name-only',COMMIT,'--','setup').decode().splitlines())
tracked=0
with tarfile.open(fileobj=io.BytesIO(git('archive',COMMIT))) as t:
 for m in t.getmembers():
  if m.isfile():assert (SNAP/m.name).read_bytes()==t.extractfile(m).read(),m.name;tracked+=1
  elif m.issym():assert os.readlink(SNAP/m.name)==m.linkname,m.name

source=['setup/src/adapters/git.ts','setup/src/adapters/process.ts','setup/src/core/plan.ts',
        'setup/src/core/engine.ts','setup/src/core/gates.ts','setup/src/stages/system.ts',
        'setup/schemas/plan.schema.json','docs/automation/CONTRACT.md']
for name in source:copy(SNAP/name,Path('source')/name)
(E/'source/production-diff.patch').write_bytes(git('diff',BASE,COMMIT,'--','setup/src'))
(E/'source/full-name-status.txt').write_bytes(git('diff','--name-status',BASE,COMMIT))
(E/'source/base-vs-prior-audit.txt').write_bytes(git('diff','--name-status',OLD,BASE))
text=(E/'validation/tests.log').read_text()
assert all(x in text for x in ['ℹ tests 397','ℹ pass 397','ℹ fail 0','ℹ skipped 0'])
matrices={}
for s in text.splitlines():
 if s.startswith(('R14_','R15_','R16_')):
  tag,_,body=s.partition(' ');matrices.setdefault(tag,[]).append(json.loads(body))
counts={tag:len(value) for tag,value in matrices.items()}
assert counts=={'R14_FAULT':36,'R14_CRASH':10,'R14_RECOVERY_FAULT':4,'R15_DOCKER_FAULT':10,
               'R15_DOCKER_CRASH':3,'R16_REAL_COMMAND':14,'R16_REFUSAL':24,'R16_PROBE_CONTROL':4}
for tag,data in matrices.items():save(Path('validation')/(tag.lower()+'.json'),data)
old=json.loads((E/'comparison/assertions.json').read_text());new=json.loads((E/'commands/assertions.json').read_text())
assert len(old)==33 and len(new)==37 and all(x['status']=='PASS' for x in old+new)
r2=rows(E/'r2-admission.jsonl');r2base=rows(E/'r2-admission-baseline.jsonl')
assert len(r2)==9 and len(r2base)==9
assert [r['acceptance'] for r in r2[:-1]]==[True,True,False,True,True,True,False,False]
for a,b in zip(r2[:-1],r2base[:-1]):
 for key in ['id','exit','counts','effects','acceptance']:assert a.get(key)==b.get(key)
save(Path('r2-product-assertions.json'),[{key:r[key] for key in ['id','exit','acceptance','fixture']} for r in r2[:-1]])
save(Path('identity-verification.json'),{
 'date':'2026-10-25','timezone':'Europe/Amsterdam','reviewed_commit':COMMIT,
 'reviewed_tree':git('rev-parse',COMMIT+'^{tree}').decode().strip(),'local_package_base':BASE,
 'previous_review':OLD,'remote_master_read_only_result':remote,'input_zip_sha256':sha(zipbytes),
 'input_zip_entries':input_entries,'input_internal_checksums_verified':len(sums),
 'all_four_attachments_equal_published_package':True,'bundle_hashes_verified':True,
 'manifest_count':len(tested),'manifest_sha256':sha((bundle/'tested-files.sha256').read_bytes()),
 'snapshot_and_reconstruction_match_manifest':True,'manifest_exactly_covers_tracked_setup':True,
 'all_tracked_snapshot_files_equal_commit':tracked,'production_changed_files':delta,
 'original_checkout_HEAD':git('rev-parse','HEAD').decode().strip(),
 'original_checkout_status':git('status','--short').decode().splitlines(),
 'reviewer_os':platform.platform(),'reviewer_arch':platform.machine(),'reviewer_uid':os.getuid(),
 'reviewer_node':subprocess.check_output(['node','--version']).decode().strip(),
 'reviewer_npm':subprocess.check_output(['npm','--version'],stderr=subprocess.DEVNULL).decode().strip(),
 'product_edits_by_reviewer':False,'git_writes':'fetch only; no commits/branches/index/push/PR/deploy'})
save(Path('validation-summary.json'),{
 'suite':{'tests':397,'pass':397,'fail':0,'skip':0},'frozen_assertions_pass':33,
 'r16_assertions_pass':37,'assertion_count_note':'37 includes one aggregate of 33; not 70 independent scenarios',
 'suite_machine_rows':counts,'r2_probes':{'cases':8,'safe':5,'unsafe':3,'same_on_baseline':True},
 'verdict':'R1.6 local scope PASS; R15-F01 closed; R2-F01/F02 OPEN; production OPEN',
 'not_run':['real sudo/APT/systemd/SSH/UFW','Docker daemon/cgroups','VM/VPS','OAuth/credentials/provider/model',
            'GitHub writes','release/deploy','physical power loss'],
 'limits':'Test container UID0; only authored stdout/argv children and fake APT effects. Not root/owner target deployment qualification.'})

checksum=E/'SHA256SUMS'
payload=sorted(p for p in OUT.rglob('*') if p.is_file() and p!=checksum and p.parent!=OUT)
payload += [OUT/'agent-factory-r16-audit-5fde93d.ru.md',OUT/'copilot-q1a-r2-1-task.ru.md',OUT/'README.md']
payload=sorted(set(payload))
checksum.write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(OUT).as_posix()}\n' for p in payload))
archive=OUT/'agent-factory-r16-review-evidence-5fde93d.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(payload+[checksum]):
  info=zipfile.ZipInfo(p.relative_to(OUT).as_posix(),date_time=(2026,10,25,16,0,0))
  info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
digest=sha(archive.read_bytes())
(OUT/(archive.name+'.sha256')).write_text(f'{digest}  {archive.name}\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for s in z.read('evidence/SHA256SUMS').decode().splitlines():
  h,name=s.split('  ',1);assert sha(z.read(name))==h,name
 entries=len(z.infolist())
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'entries':entries,'sha256':digest,
 'tracked_snapshot_files_verified':tracked,'tested_manifest':len(tested),'input_checksums':len(sums),
 'tests':397,'frozen_assertions':33,'command_assertions':37,'R1.6':'PASS local','R2':'OPEN'},indent=2))
