import subprocess,pathlib,json,os,time
r=pathlib.Path('/private/tmp/af-r21');env={**os.environ,'PATH':'/Users/splswrd/.nvm/versions/node/v24.12.0/bin:'+os.environ['PATH']};rows=[]
def run(name,argv,cwd=None,expected=0):
 start=time.time()
 with (r/(name+'.log')).open('w') as f:p=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=150)
 rows.append({'argv':argv,'cwd':str(cwd or pathlib.Path.cwd()),'exit_code':p.returncode,'expected_exit':expected,'log':name+'.log','elapsed_seconds':round(time.time()-start,3)});(r/'comparison-commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==expected,(name,p.returncode)
for name,checkout in [('baseline',r/'base'),('fixed',r/'fixed-release')]:run(name+'-r2-final',['node',str(r/'input/evidence/r2-admission-probes.cjs'),str(checkout)])
run('red-build-final',['npm','--prefix','setup','run','build','--silent'],r/'red');run('red-tests-final',['node','--test','setup/dist/tests/integration/q1a-r21-admission.test.js'],r/'red',1)
for name,args in [('ci',['ci','--ignore-scripts','--no-audit','--no-fund']),('build',['run','build','--silent'])]:run('historical-r15-'+name,['npm','--prefix','setup',*args],r/'historical-r15')
runner=r/'r16-frozen/runners/command-identity-probes.cjs'
for label,checkout in [('baseline',r/'historical-r15'),('fixed',r/'fixed-release')]:
 for mode in ['adapter','stage']:
  log=label+'-'+mode+'-final';run(log,['node',str(runner),str(checkout),mode]);(r/(log+'.jsonl')).write_bytes((r/(log+'.log')).read_bytes())
run('frozen-driver',['python3',str(r/'r16-frozen/runners/run-evidence.py'),'--baseline',str(r/'base'),'--fixed',str(r/'fixed-release'),'--inputs',str(r/'r16-frozen/inputs'),'--logs',str(r/'frozen-comparisons')])
run('frozen-checker',['python3',str(r/'r16-frozen/runners/check-results.py'),str(r/'frozen-comparisons')]);(r/'comparison-assertions.json').write_bytes((r/'frozen-checker.log').read_bytes())
run('command-checker',['python3',str(r/'r16-frozen/runners/check-r16.py'),str(r)]);(r/'command-assertions.json').write_bytes((r/'command-checker.log').read_bytes())
