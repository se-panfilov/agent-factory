# Privilege boundary and mutation map (Q1A snapshot)

This file documents **implemented behavior** after Q1A remediation, not target architecture.

## Serialization model

`setup/src/core/lock.ts` provides one installation lock for ordinary writers. In current code, the following commands run under this lock before state mutation:

- `init`, `preflight`, `plan`, `apply`, `resume` (via `plan` + `apply`), `verify`, `status --refresh`
- `gate approve`
- `backup create`, `backup verify`
- `auth login`, `auth status`
- `smoke`, `inference disable`

Read-only paths (`status` without `--refresh`, `gate list`, blocked `restore/update/inference probe`, diagnostic read inside `cancel`/`recover`) do not write state.  
`cancel`/`recover --lock-only` use a separate protocol by design and are not ordinary writer bypasses.

## Operation → privilege/admission matrix

| Operation | CLI argv shape | UID policy | Trusted inputs / paths | Gate / admission | Postcondition evidence | Recovery path | State |
|---|---|---|---|---|---|---|---|
| Initialize installer state | `factory-setup init --profile ... --config PATH` | No root requirement in command itself; writes only setup state/config paths | Config schema + local setup paths | Contract/schema validation | State file exists and envelope returned | Re-run init with same config; lock prevents concurrent writer races | **Implemented** |
| Record preflight observation (S01) | `factory-setup preflight --config PATH` | No explicit owner check; state mutation only | S01 observe output + setup state dir | Stage registration + lock | Persisted `S01` observed status/checks | `verify`/`status --refresh` after fixing host preconditions | **Implemented** |
| Build plan + persist required approvals | `factory-setup plan --config PATH [--stage ID]` | No explicit owner check; no host mutation | Config hash, selected closure, stage plans, state dir | Plan consistency + in-flight barrier + lock; stage-only and operation gates persisted | `plan.json` + persisted required approvals (id, operation_id, ttl, status) | Re-plan after drift/expiry | **Implemented** |
| Approve manual gate | `factory-setup gate approve --config PATH --id ID --plan-hash HASH` | No owner check; state mutation only | Existing persisted gate records | Lock + plan hash + gate id + TTL check (`now >= expires_at` => expired) | Gate status becomes `approved`; expired gates return non-zero and remain expired | New plan + new gate approval | **Implemented** |
| Execute generic stage plan | `factory-setup apply --config PATH --plan PATH` | For mutating stage operations: ordinary owner only (`uid != 0`, username == `expected_user`) | Reviewed plan bytes, state/journal, stage adapters | Admission checks (installation/contract/profile/capabilities/dependency order/gate consistency), lock, **shared in-flight barrier before ordinary effects**, per-op gate binding, cancel checks before/between effects | Attempt-scoped journal transitions (`intent -> effect -> verify -> checkpoint`) + `stage.verify()`/`stage.observe()`; invalid order/legacy records force recovery | `recover`/`resume` with durable in-flight marker | **Implemented (core), not production-qualified** |
| Resume | `factory-setup resume --config PATH [--stage ID]` | Same as `apply` | Recomputed plan from current config + persisted state | Same as `plan` + `apply`; generic apply policy still enforced | Same as `apply` | Same as `apply` | **Implemented (core)** |
| Refresh recorded status | `factory-setup status --config PATH --refresh` | No owner check; state mutation only | Selected stage closure observations | Lock + state load; no silent init in read-only mode | Persisted observed status/drift + age metadata in envelope | `plan`/`apply`/`recover` depending on drift | **Implemented** |
| Read recorded status only | `factory-setup status --config PATH` | Read-only | Persisted state snapshot | No hidden writes | Envelope marks `recorded_state_only=true` | Run `status --refresh` / `verify` for fresh observation | **Implemented** |
| Verify selected installation closure | `factory-setup verify --config PATH [--stage ID]` | No owner check for verify itself | Stage verify+observe over selected closure | Lock + closure resolution (selected stages by default) | Aggregated stage outcomes and C03 exit code mapping | `plan`/`recover`/`resume` depending on typed failure | **Implemented** |
| Backup create (S11) | `factory-setup backup create --config PATH` | Ordinary owner required | Backup config + state/app paths | Lock + S11 operation policy | Backup id/path + retention/prune data in envelope | Backup verify or recover | **Implemented (core)** |
| Backup verify (S11) | `factory-setup backup verify --config PATH [--backup-id ID]` | No explicit owner check | Backup bytes + manifest | Lock + verification checks | Verified backup metadata in envelope | Restore remains blocked (see below) | **Implemented (core)** |
| Auth login/status (S08) | `factory-setup auth login|status --config PATH` | `auth login`: ordinary owner required; `auth status`: no owner gate | Auth dir and state paths | Lock + command-specific checks; **ordinary auth login blocked when unresolved in-flight exists (pre-adapter)** | Persisted S08 observation | Re-login when missing/expired auth | **Implemented (core)** |
| Smoke run | `factory-setup smoke --config PATH --provider fake|live --fixture toy` | Ordinary owner required | Selected provider/fixture + stage adapters | Lock + provider constraints + stage policy; **blocked before provider/process adapter call when unresolved in-flight exists** | Envelope data for provider/fixture/status | Cancel/recover depending on failure mode | **Implemented (core), live qualification OPEN** |
| Disable inference scheduling | `factory-setup inference disable --config PATH` | Ordinary owner required | Inference compose/runtime paths | Lock + S12 checks; **blocked before adapter call when unresolved in-flight exists** | Envelope confirms blocked scheduling and stop status | `resume`/`verify` | **Implemented (core)** |
| Cancel run | `factory-setup cancel --config PATH` | No owner check for request file; emergency path uses adapter policy | Cancel request file / emergency resource stop logic | Request is bound to run identity; consumed by running apply between effects | Request path (normal) or emergency stop details | Resume/recover after inspection | **Implemented (core)** |
| Recover (full + lock-only) | `factory-setup recover --config PATH [--lock-only]` | No root escalation | Recovery marker/previous snapshot/journal evidence + `state-commit.json` proof + lock metadata | `--lock-only`: stale-owner proof only. Full recover: (1) no-op when state is consistent, (2) restores trusted `.previous` snapshot only for supported proven case, (3) prepared decision is immutable across resume, (4) returns exit 8 for unresolved marker/journal/manifest/in-flight evidence without cleanup-by-deletion | Recovery outcome (`recovery_not_required` / `recovered_previous_generation`) or explicit blocked reason/evidence | Keep evidence, then manual reconciliation or resume/re-plan per outcome | **Implemented for state/recovery core; external reconciler remains blocked** |
| Restore | `factory-setup restore --config PATH --backup-id ID --plan PATH` | No mutation allowed in Q1A | N/A (blocked before payload handling) | Hard blocked by entrypoint policy | Returns blocked envelope/exit before side effects | Q4 restore transaction/payload hardening required | **Blocked (containment)** |
| Update plan/apply | `factory-setup update plan|apply ...` | No mutation allowed in Q1A | N/A (blocked) | Dedicated update flow intentionally blocked | Returns blocked envelope/exit | Q5 update admission + transaction work required | **Blocked (containment)** |
| Inference probe | `factory-setup inference probe --config PATH --checks ...` | No mutation allowed in Q1A | N/A (blocked) | Explicit capability blocker | Returns blocked envelope/exit | Reviewed implementation required | **Blocked (containment)** |

## Important boundaries still not claimed as done

- No claim of completed narrow privileged executor (`sudo` boundary and process-tree supervision are Q1B/Q2).
- No claim of complete per-effect cancellation/cleanup semantics across every stage internals; this pass aligns journal/recovery protocol but does not finish full process-tree cancellation model.
- No claim that S03 rollback, S04 host isolation, or live/provider paths are production-qualified.
- No claim that restore/update/inference probe implementations are complete; these are intentionally blocked entrypoints in Q1A.

## R1.3 operation durability boundary (implemented)

`SetupEngine.apply` executes approved operations one-by-one with durable journal/state boundaries owned by the core engine:

1. persist in-flight operation + state commit manifest update;
2. append journal `intent`;
3. run stage operation and validate receipt identity (operation/stage/resource);
4. append `effect` + `verify` records;
5. persist state with checkpoint metadata and append journal `checkpoint`;
6. update `state-commit.json` `last_effect_checkpoint` with exact checkpoint identity.

This means completed operations are durable before the next operation starts, and a late failure preserves known completed progress plus uncertainty for the interrupted operation.

## R1.3 unified recovery evidence admission

Recovery admission is now evaluated from one evidence set (`primary`, `previous`, `quarantine`, `journal`, `state-commit`, `marker`) before any cleanup:

| Evidence | Role | Admission rule |
|---|---|---|
| `state.json` (primary) | Current generation candidate | Missing primary does not imply fresh state when any other evidence exists. |
| `state.json.previous` | Recovery candidate snapshot | Candidate must be trusted and generation-proofed; no in-flight operation allowed. |
| `state.json.corrupt-*` | Quarantined uncertainty | Any quarantine entry blocks automatic cleanup and marker removal. |
| `events.jsonl` | Operation history/proof chain | Parse/order/legacy/unresolved evidence blocks ordinary effects and blocks unsafe recover cleanup. |
| `state-commit.json` | Durable generation metadata | Manifest is standalone evidence; missing/invalid/unsupported/foreign manifest is a typed blocker. |
| `recovery-required.json` | Recovery phase/decision marker | Prepared decision is immutable; `primary_restored` cleanup performs full admission before marker deletion. |

Read-only diagnostics (`status`, `gate list`, read-only load paths) do not mutate this evidence set.

## Q1A-R1.4 protocol correction

The R1.3 description of operation checkpoints as final recovery proof was incomplete. See [lifecycle-r14.md](lifecycle-r14.md) for the transaction/crash table and typed internal clean/progress proof. Ordinary load and every recovery phase now call the same contradictory-evidence evaluator before mutation. Quarantine is not ignored by a valid primary. A prepared decision contains the exact source manifest and candidate hash; continuation accepts only that source or its defined restore transition. Restoring a proven clean metadata predecessor preserves checkpoint/progress proof and can finish manifest publication after a partial restore. Legacy prepared decisions without the immutable source binding remain blocked and preserved.
