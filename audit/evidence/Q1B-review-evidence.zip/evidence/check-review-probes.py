import json,sys
from pathlib import Path
p=Path(sys.argv[1])
for name in ['group-census.jsonl','group-census-confirm.jsonl']:
 r=json.loads((p/name).read_text());assert r['result']['exitCode']==0 and r['result']['cleanup']=='confirmed' and r['writeAfterReturn'] is True
for name in ['spawn-sync.jsonl','spawn-sync-confirm.jsonl']:
 rows=[json.loads(x) for x in (p/name).read_text().splitlines()];assert len(rows)==2
 assert rows[0]['error']['code']=='E2BIG' and rows[0]['result'] is None
 assert len(rows[0]['registeredProcesses'])==1 and rows[0]['registeredProcesses'][0]['pid'] is None
 assert rows[1]['listeners']==1 and rows[1]['error']=='E2BIG'
print(json.dumps({'evidence_check':'PASS','product_verdict':'CHANGES_REQUIRED_LOCAL','F01':'REPRODUCED','F02':'REPRODUCED','note':'checker0 validates preserved defect evidence, not product acceptance'}))
