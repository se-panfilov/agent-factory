"""Package the exact completed review. Read-only product/Git checks; no repository edits."""
from pathlib import Path
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parents[2]
out = root/'r211-review'
evidence = out/'evidence'
repo = root/'agent-factory'
snapshot = root/'agent-factory-review-117a71e'
reconstructed = root/'agent-factory-r211-reconstructed'
incoming = out/'incoming'
replay = root/'r211-portable-replay'
commit = '117a71e3607659e97509b99c1662131c3970c112'
env = {**os.environ, 'GIT_OPTIONAL_LOCKS':'0'}
digest = lambda data: hashlib.sha256(data).hexdigest()

for line in (incoming/'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ',1)
    assert digest((incoming/name).read_bytes()) == expected, name
manifest = []
for line in (incoming/'tested-files.sha256').read_text().splitlines():
    expected, name = line.split('  ',1)
    for tree in [snapshot, reconstructed, replay/'fixed', out/'source']:
        assert digest((tree/name).read_bytes()) == expected, (tree, name)
    manifest.append(name)
tracked = subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'setup'],cwd=repo,env=env,text=True).splitlines()
assert set(tracked) == set(manifest) and len(manifest) == 148
count = 0
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',commit],cwd=repo,env=env))) as stream:
    for member in stream.getmembers():
        if member.isfile():
            assert stream.extractfile(member).read() == (snapshot/member.name).read_bytes(), member.name
            count += 1
assert count == 415
for folder in [evidence/'validation', replay/'validation']:
    assert all(row['exit_code'] == 0 for row in json.loads((folder/'commands.json').read_text()))
    suite = (folder/'tests.log').read_text()
    assert all(s in suite for s in ['tests 446','pass 446','fail 0','skipped 0','cancelled 0'])
assert not (replay/'result.json').exists(), 'This packaging description records the incomplete combined replay.'
for folder in [evidence/'comparisons-rerun']:
    for filename, expected in [('comparison-assertions.json',33),('command-assertions.json',37),('r2-product-assertions.json',39)]:
        rows = json.loads((folder/filename).read_text())
        assert len(rows) == expected and all(r['status']=='PASS' for r in rows)
for filename in ['access-fixed-oracle.json','access-legacy-oracle.json']:
    result = json.loads((evidence/filename).read_text())
    assert result['product_pass'] == 13 and result['product_fail'] == 0
for label in ['baseline','fixed']:
    result = json.loads((evidence/f'context-{label}-desired-oracle.json').read_text())
    assert result['pass'] == 2 and result['fail'] == 3
    rows = [json.loads(line) for line in (evidence/f'recovery-{label}-measured.jsonl').read_text().splitlines()]
    assert len(rows)==2 and all(r['recover']==0 and r['resume']==2 and r['explicit_review_resume']==0
                              and r['before']==r['after'] and not r['desired_acceptance'] for r in rows)
unexpected = [r for r in json.loads((replay/'commands.json').read_text()) if r['exit_code']!=r['expected_exit']]
assert len(unexpected)==2 and {r['log'] for r in unexpected}=={'logs/comparisons.log','logs/comparisons-resumed.log'} and all(r['exit_code']==1 for r in unexpected)
assert 'A21-14:command37' in (replay/'comparisons/r2-product-assertions.json').read_text()
assert len((replay/'comparisons/baseline-stage-final.jsonl').read_text().splitlines())==1
assert "KeyError: 'C08'" in (replay/'comparisons-resumed/comparison-assertions.json').read_text()
assert len((replay/'comparisons-resumed/frozen-comparisons/fixed-comparison.jsonl').read_text().splitlines())==7
portable = evidence/'portable-replay'
portable.mkdir(exist_ok=True)
for folder in ['logs','validation','comparisons','comparisons-resumed']:
    shutil.copytree(replay/folder,portable/folder,dirs_exist_ok=True)
for filename in ['commands.json']:
    shutil.copyfile(replay/filename,portable/filename)
remote = subprocess.check_output(['git','ls-remote','origin','refs/heads/master'],cwd=repo,env=env,text=True).split()[0]
assert remote == commit, 'Remote changed: report exact reviewed commit instead of assuming current master.'
identity = json.loads((evidence/'identity-verification.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,env=env,text=True).strip() == identity['owner_checkout_head']
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,env=env,text=True) == identity['owner_checkout_status']
assert digest((repo/'.git/index').read_bytes()) == identity['owner_index_sha256']
identity.update({'remote_master_at_packaging':remote,'portable_full_replay_completed':False,'portable_explicit_resume_after_incomplete_output':True,'portable_status':'INCOMPLETE: missing command rows, then missing frozen C08; failed checks retained',
                 'scoped_R21_F01_F02':'ACCEPTED local','production':'OPEN','supplementary_recovery':'known-red; explicit review workaround verified',
                 'next_task':'Q1A-R2.2','all_tracked_snapshot_files_verified':count})
(evidence/'identity-verification.json').write_text(json.dumps(identity,indent=2)+'\n')
target = out/'agent-factory-r211-review-evidence-117a71e.zip'
checksum_file = Path(str(target)+'.sha256')
payload = [(p.relative_to(out).as_posix(),p) for p in out.rglob('*')
           if p.is_file() and p not in [target,checksum_file] and '__pycache__' not in p.parts]
payload.sort()
assert len(payload) == len({name for name,p in payload})
sums = ''.join(f'{digest(p.read_bytes())}  {name}\n' for name,p in payload).encode()
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,p in payload: archive.write(p,name)
    archive.writestr('SHA256SUMS',sums)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for line in archive.read('SHA256SUMS').decode().splitlines():
        expected,name=line.split('  ',1); assert digest(archive.read(name)) == expected
    for name in ['agent-factory-r211-audit-117a71e.ru.md','copilot-q1a-r2-2-task.ru.md','README.md']:
        assert archive.read(name) == (out/name).read_bytes()
checksum = digest(target.read_bytes())
checksum_file.write_text(f'{checksum}  {target.name}\n')
print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'entries':len(payload)+1,
                  'sha256':checksum,'remote_master':remote,'full_replay_completed':False,'independent_measurements_completed':True},indent=2))
