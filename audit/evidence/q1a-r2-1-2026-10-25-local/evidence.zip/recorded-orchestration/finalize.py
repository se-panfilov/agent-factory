from pathlib import Path
import shutil,json,hashlib,zipfile,subprocess,os
r=Path('/Users/splswrd/work/agent-factory');t=Path('/private/tmp/af-r21');o=r/'audit/evidence/q1a-r2-1-2026-10-25-local';stage=t/'package'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((t/'reconstruction-after.json').read_text())['manifest_sha256']==sha(o/'tested-files.sha256')
assert json.loads((t/'final-reconstruction.json').read_text())['manifest_sha256']==sha(o/'tested-files.sha256')
commands=json.loads((t/'final-validation/commands.json').read_text());assert len(commands)==5 and all(row['exit_code']==0 for row in commands)
assert 'ℹ pass 429' in (t/'final-validation/tests.log').read_text() and 'ℹ fail 0' in (t/'final-validation/tests.log').read_text()
assert len(json.loads((t/'comparison-assertions.json').read_text()))==33
assert len(json.loads((t/'command-assertions.json').read_text()))==37
logs=stage/'logs';logs.mkdir(exist_ok=True)
for p in t.iterdir():
 if p.is_file() and p.suffix in ['.json','.jsonl','.log','.patch','.txt']:shutil.copy2(p,logs/p.name)
for name in ['final-validation','frozen-comparisons','pre-strict-type-validation','pre-completion-validation']:shutil.copytree(t/name,logs/name,dirs_exist_ok=True)
recorded=stage/'recorded-orchestration';recorded.mkdir(exist_ok=True)
for name in ['prepare.py','validate.py','comparisons.py','revalidate.py','revalidate-completion.py','package.py','finalize.py']:shutil.copy2(t/name,recorded/name)
bundle=stage/'bundle';bundle.mkdir(exist_ok=True)
for name in ['identity.json','report.md','full-local.patch','new-files.tar','new-files.json','tested-files.sha256','deletions.json']:shutil.copy2(o/name,bundle/name)
shutil.copy2(t/'README.md',stage/'README.md');shutil.copy2(t/'README.md',o/'README.md')
files=sorted(p for p in stage.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(stage/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(stage))+'\n' for p in files))
zpath=o/'evidence.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(p for p in stage.rglob('*') if p.is_file()):
  info=zipfile.ZipInfo(str(p.relative_to(stage)),(2026,10,25,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes(),compresslevel=9)
(o/'evidence.zip.sha256').write_text(sha(zpath)+'  evidence.zip\n')
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
 assert z.read('bundle/report.md')==(o/'report.md').read_bytes()==(r/'docs/audits/remediation-q1a-r2-1-2026-10-25.md').read_bytes()
 assert z.read('bundle/full-local.patch')==(o/'full-local.patch').read_bytes()
 assert z.read('runners/r2-admission-probes.cjs')==(t/'input/evidence/r2-admission-probes.cjs').read_bytes()
identity=json.loads((o/'identity.json').read_text());assert sha(o/'full-local.patch')==identity['patch_sha256'];assert sha(o/'report.md')==identity['report_sha256'];assert sha(r/'.git/index')==identity['index_sha256_before']==identity['index_sha256_after']
for l in (o/'tested-files.sha256').read_text().splitlines():
 h,n=l.split('  ',1);assert sha(r/n)==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip()==identity['base_commit']
print(json.dumps({'zip':str(zpath),'zip_sha256':sha(zpath),'bytes':zpath.stat().st_size,'archive_files':len(files)+1,'report_bytes_match':True,'original_runner_bytes_match':True,'index_bytes_unchanged':True,'tested_manifest':identity['tested_manifest_sha256'],'tests':429,'failed':0,'skipped':0},indent=2))
