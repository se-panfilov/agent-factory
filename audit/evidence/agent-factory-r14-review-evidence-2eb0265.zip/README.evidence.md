# Independent R1.4 review evidence

Reviewed master: `2eb026527d3448fc0d455f6fe8713cba61c0d3c5`. Report finalized 2026-10-25 Europe/Amsterdam.

The audit and next Copilot task are included at archive root. `SHA256SUMS` covers the packaged artifacts. `evidence/identity.json` records source/runtime identity; `reviewed-files.sha256` covers every tracked file in the exported checkout and was checked against the Git commit after validation. Product source was not modified by this review.

The independent full setup run passed 254 tests. Raw output is in `evidence/tests.log`; matrix JSON files are extracted from that same run, not additional tests. The comparison runner's 12 historic cases were rerun and their actual outputs checked against corrected R1.4 expectations. Those narrow checks pass; they do not cover all real-host cases.

`evidence/new-probes.jsonl` records five failing safety expectations (three S05 entrypoints, one clean Docker lifecycle, one SSH Include collector case) plus one passing actual Docker adapter contract control. These support three findings. `harness_ok` means a scenario ran; `acceptance` is the product expectation. The whole probe script may exit 0 while counterexamples are present: inspect the JSON. `new-probes-harness-error.jsonl` is the discarded first run with a formatter bug and is retained only for transparency.

To reproduce, use Node 24, install with `npm --prefix setup ci --ignore-scripts --no-audit --no-fund`, then run `npm --prefix setup run typecheck --silent` and `npm --prefix setup run test --silent` in an exported reviewed checkout. Run `evidence/r14-new-probes.cjs` with Node and pass the absolute checkout path as its first argument. It defaults to the adjacent `frozen-r14-fixtures` directory. The optional second argument selects another frozen fixture directory. Those fixtures are baseline compiled fixture definitions; original test callbacks are not executed. Relative production imports resolve against the supplied checkout, so the same fixtures can compare baseline and locally fixed code.

The `input-r14` directory contains selected supplied Copilot evidence and its runners for provenance. Its copied `SHA256SUMS` is the ORIGINAL full input archive manifest; not every input archive member is duplicated here. `input-checksums-verification.json` records verification of that entire original archive. `source-diff.patch` is the reviewed setup source/tests/docs delta from R1.3 to R1.4, not an implementation patch produced by this reviewer.

No real sudo, apt, systemd, SSH/firewall changes, Docker daemon operations, OAuth, paid calls, GitHub writes or VM provisioning were performed. Process adapter calls in the new probes are all intercepted. Existing child crash tests terminate only their own test children. Live/VM/power-loss qualification remains NOT RUN.

The next Copilot task must remain local: no commits, push, new branches or PRs. A future audit needs its local patch, new-file payload and tested file manifest if changes are not published by the owner.
