import subprocess,pathlib,json,os,time
r=pathlib.Path('/private/tmp/af-r16');env={**os.environ,'PATH':'/Users/splswrd/.nvm/versions/node/v24.12.0/bin:'+os.environ['PATH']};rows=[]
for label,repo in [('baseline',r/'base'),('fixed',r/'fixed')]:
 for mode in ['adapter','stage']:
  argv=['node',str(r/'input/evidence/command-identity-probes.cjs'),str(repo),mode];start=time.time();log=label+'-'+mode+'-final.jsonl'
  with open(r/log,'w') as f:p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=45)
  rows.append({'argv':argv,'exit_code':p.returncode,'log':log,'elapsed_seconds':round(time.time()-start,3)});(r/'audit-harness-commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0
argv=['python3',str(r/'r15-frozen/runners/run-evidence.py'),'--baseline',str(r/'base'),'--fixed',str(r/'fixed'),'--inputs',str(r/'r15-frozen/inputs'),'--logs',str(r/'frozen-comparisons')]
with open(r/'frozen-driver.log','w') as f:p=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=120)
assert p.returncode==0
with open(r/'comparison-assertions.json','w') as f:p=subprocess.run(['python3',str(r/'r15-frozen/runners/check-results.py'),str(r/'frozen-comparisons')],stdout=f,stderr=subprocess.STDOUT,env=env)
assert p.returncode==0
