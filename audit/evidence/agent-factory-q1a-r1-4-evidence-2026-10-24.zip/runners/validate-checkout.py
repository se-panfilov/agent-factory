#!/usr/bin/env python3
"""Run required real-Node24 commands and identical local probes; retain all bytes and exits."""
import json, os, pathlib, subprocess, sys
checkout=pathlib.Path(sys.argv[1]).resolve(); output=pathlib.Path(sys.argv[2]).resolve(); output.mkdir(parents=True,exist_ok=True)
runners=pathlib.Path(__file__).resolve().parent; fixtures=runners.parent/'frozen-fixtures'
commands=[('node',['node','--version']),('npm',['npm','--version']),
 ('ci',['npm','--prefix','setup','ci','--ignore-scripts','--no-audit','--no-fund']),
 ('typecheck',['npm','--prefix','setup','run','typecheck','--silent']),
 ('tests',['npm','--prefix','setup','run','test','--silent']),
 ('comparison',['node',str(runners/'r14-comparison.cjs'),str(checkout),str(fixtures)]),
 ('lifecycle',['node',str(runners/'lifecycle-controls.cjs'),str(checkout)]),
 ('stages',['node',str(runners/'stage-compat-probes.cjs'),str(checkout)]),
 ('s06',['node',str(runners/'s06-noop-probe.cjs'),str(checkout)])]
results=[]
for name,args in commands:
 result=subprocess.run(args,cwd=checkout,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
 (output/(name+'.log')).write_bytes(result.stdout)
 results.append({'name':name,'cwd':str(checkout),'argv':args,'exit_code':result.returncode,'log':name+'.log'})
 (output/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name, result.returncode, flush=True)
 if name=='node' and not result.stdout.startswith(b'v24.'):
  raise SystemExit('Real Node 24 required, refusing substitute runtime')
 if result.returncode: raise SystemExit(result.returncode)
