# R1.5 independent review evidence

Reviewed master: `b888082167b5edc50977a6dcda997b40e962da8d` (2026-10-25). Verdict: **PARTIAL**, one open P1 finding R15-F01. No product edits, commits, push, branches, PR or deploy by reviewer.

Start with `agent-factory-r15-audit-b888082.ru.md`; give `copilot-r16-task.ru.md` to the implementation agent. The next implementation stays local.

## Contents

- `evidence/identity-verification.json`: Git identity, attachment/manifest/reconstruction equality, environment and limits.
- `evidence/validation/`: independent npm/typecheck/full test logs and fault/crash rows extracted from that run.
- `evidence/comparison/`: independent rerun of frozen baseline/fixed scenarios; 33 product assertions PASS.
- `evidence/command-identity-probes.cjs`: standalone reviewer reproduction of the command identity defect.
- `evidence/command-identity*.jsonl`: actual adapter and stage modes, each with one positive and three negative product outcomes.
- `evidence/probe-acceptance.json`: compact per-case results. Harness success is not product acceptance.
- `evidence/input/copilot-r15-evidence.zip`: original provided ZIP, unchanged, with its own checksums/runners/fixtures/patch/logs.
- `evidence/source/`: exact production diff and relevant source snapshots, including unchanged ProcessAdapter.
- `evidence/SHA256SUMS`: checksums of all payload files, excluding itself.

The original checksum file under `evidence/input/original-evidence.zip.sha256` uses the original name `evidence.zip`. The unchanged input ZIP has been renamed `copilot-r15-evidence.zip` here; verify its digest against that file or the outer SHA256SUMS.

## Reproduce the new finding

Use an isolated disposable local directory containing a copy/export of the reviewed commit. Use Node major 24, without credentials. No real Docker/sudo/SSH/systemd/VPS commands are required. The harness runs only locally authored stdout-only Node fixtures. It does not use an actual release tarball or full engine journal for its stage-mode trust fixture.

Inside that repository copy:

```text
npm --prefix setup ci --ignore-scripts --no-audit --no-fund
npm --prefix setup run typecheck --silent
npm --prefix setup run test --silent
```

From the unpacked review bundle, replace `/absolute/path/to/snapshot` with that compiled copy:

```text
node evidence/command-identity-probes.cjs /absolute/path/to/snapshot adapter
node evidence/command-identity-probes.cjs /absolute/path/to/snapshot stage
```

At `b888082`, W01 prints `REVIEWED_ENTRY`; W02/W03 print `UNREVIEWED_CWD_ENTRY`; W04 prints `UNBOUND_OPTION_EVAL`. All four manifests pass the real schema. All help probes return true and all stage-mode observations are `verified`; only W01 is correct. Each mode runs eight harmless children. Product acceptance is explicitly false for W02/W03/W04 even though the harness exits zero. The audit runtime was Node v24.22.1 on Linux x86_64, UID 0; this is a unit/adapter test environment, not target host qualification.

The harness creates its own temporary directories and temporarily changes CWD only inside its separate test process to model an installer invoked elsewhere. It never changes the repository's working directory/state or invokes privileged/network tools. SHA-256 is computed from actual temporary file bytes in an intercepted hash command; command execution goes through the real NodeProcessAdapter. Pinned node in the fixture is a symlink to the currently running Node; no runtime-install security claim follows from this.

After the fix, preserve W01 as a positive execution control. W02/W03 must execute the checked deployment files. W04 must be rejected before executable invocation under the requested strict grammar. Do not make all cases pass by refusing every valid command. The test contract in the next task includes the stronger assertions beyond this original frozen harness.

## Reproduce old comparisons / supplied package

Unpack `evidence/input/copilot-r15-evidence.zip` into a separate directory after checking its checksum and safe archive paths. It contains `bundle/full-local.patch`, `bundle/tested-files.sha256`, runners and frozen inputs. Follow that package README for `d7d1411 + patch` reconstruction; new-file tar is redundant if the full patch is applied. Do not stage, commit or reset the original repository.

Compile temporary baseline `2eb0265` and fixed `b888082` copies. The former's setup code equals supplied base `d7d1411`. Run the provided `runners/run-evidence.py` with `--baseline`, `--fixed`, `--inputs` and `--logs`, then `runners/check-results.py` on those output logs. Independent actual argv and results are preserved in `evidence/comparison/independent-commands.json` and `assertions.json`.

Known real-host blockers remain: S03 cutover/manual rollback markers, privileged executor and unsafe Docker config temporary-file path, plus the previously open roadmap. **NOT RUN:** real privileged host operations, Docker daemon, credentials/OAuth/provider/model calls, GitHub writes, VM/VPS deployment and physical power loss.

`evidence/package-review.py` records packaging/verification performed in the auditor workspace. It expects the original review inputs and temporary snapshots; it is not required to run the standalone counterexample or verify ZIP checksums. It performs no Git mutations.
