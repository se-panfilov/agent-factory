# Independent review of agent-factory Q1A-R2.1

Reviewed master: `d8728f56e847a9da75b9f21d8e6e6725a9bd295e`.
Actual package base: `ca6d0b6f2a75f3c97a80468bbc2bdcbe2db7a4ff`.
Verdict: R2-F01/F02 CLOSED local; R2.1 PARTIAL because of S03 continuation; production OPEN.

Read the Russian audit first, then the R2.1.1 Copilot task. No commits, push, branches,
worktree, PR, merge, tag, release or deployment are authorized. All changes remain local.

Contents:

- `agent-factory-r21-audit-d8728f5.ru.md`: independent findings, acceptance limits and roadmap.
- `copilot-q1a-r2-1-1-task.ru.md`: focused next task and acceptance criteria.
- `incoming/`: complete unchanged extracted Copilot evidence package, including full patch,
  new-file payload, manifest, original runners/fixtures and original logs.
- `evidence/validation/`: independent exact-master ci/typecheck/429-test logs.
- `evidence/comparisons/`: independent old R2, frozen33 and command37 measurements/checkers.
- `evidence/access-continuation-probes.cjs`: new actual-engine/S03 counterexamples, fake host effects only.
- `evidence/access-continuation-{fixed,baseline}.jsonl`: final 13-case runs for each tree.
- `evidence/check-access-continuation.py`: product oracle; observed findings versus desired fixed behavior.
- `evidence/access-*-assertions.json` and `access-desired-product-red.json`: explicit product results.
- `evidence/identity.json`, `verification.json`, command logs and notes: provenance and limitations.

Verify archive CRC and `SHA256SUMS` after extraction. The outer ZIP checksum is separate.
Checksums establish bytes, not semantic correctness. The 37 command assertions include
one aggregate of the frozen33; the 39 R2 assertions also include controls/aggregate checks.

For a complete replay, use Python 3.12+ and real Node major24/npm. With this ZIP extracted,
run `python3 evidence/reproduce-review.py --help`, then pass the absolute path to a local
Git clone containing the three recorded commits and an empty disposable output directory
via `--repo` and `--work`. The runner archives Git objects without touching the checkout,
reconstructs base+patch, installs locked dependencies with scripts disabled, runs tests,
and logs argv/cwd/exits/elapsed. It does not fetch or create Git refs. Network may be needed
only for npm dependencies. It checks the fixed-version known-failure oracle deliberately:
the S03 desired-product checker must fail with 10 cases for this reviewed version.

For a later implementation, build its setup tree and run the unchanged
`access-continuation-probes.cjs` with that tree's absolute path; capture stdout as JSONL.
Then run `check-access-continuation.py` with that JSONL and `--expect fixed`.
The desired outcome is 13/13 with exit0. `--expect observed-r21` checks the historical
known-defect outcomes and must not be used as a green acceptance gate for the repair.

The original R2 runner uses ca6d0b6 as its unsafe baseline. The historical command checker
uses b888082 as its R1.5 unsafe baseline. The new S03 remediation uses d8728f5 as its actual
baseline. Do not mix these roles or weaken the old oracles to make new code pass.

An initial reviewer harness wrongly expected cancellation exit6; the contract returns130.
Its logs are retained as `access-continuation-initial.*` and are not product failures.
The final runner uses130. Pre-enrichment logs contain the first 11-case measurement;
the final 13 cases add completed-disarm controls and before/after evidence hashes.
Only final logs define the reported matrix; these overlapping runs are not unique tests.

Real sudo/APT/systemd/SSH/UFW/Docker-daemon, OAuth/secrets/model/provider/GitHub writes,
VM/VPS provisioning, releases and deploys were NOT RUN. New S03 probes create fresh
engine/stage instances, use the real cancel API and durable engine evidence, and model
external resources in memory. Separate-process S03 continuation is required by the next task.
