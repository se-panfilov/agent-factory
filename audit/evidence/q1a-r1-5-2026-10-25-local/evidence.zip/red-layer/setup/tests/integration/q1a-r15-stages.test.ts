import test from "node:test";
import assert from "node:assert/strict";
import { r14Fixture, r14Noop } from "../helpers/r14-engine";
import { FakeApplicationAdapter, makeCheckout, makeRelease } from "../helpers/r15-application";
import { FakeDockerAdapter, baseObservation } from "../helpers/r15-docker";
import { accessInventory } from "../helpers/r15-access";
import { createApplicationStage } from "../../src/stages/application";
import { createDockerStage } from "../../src/stages/docker";
import { observeAccessInputProof } from "../../src/stages/access";
for (const command of ["plan", "verify", "status-refresh"] as const) {
  test(`V01 trusted S05 detected tamper refuses ${command} before probe adapter`, async () => {
    const x = await r14Fixture("S05"), a = new FakeApplicationAdapter(makeCheckout(x.config), makeRelease(x.config));
    const e = x.engine([r14Noop("S04"), createApplicationStage(a)]); await x.planAndApprove(e);
    assert.equal((await e.run("apply", x.applyOptions)).exitCode, 0);
    const before = a.probeCalls; assert.ok(before > 0); a.hashMismatches = ["runner.js:hash-mismatch"];
    const result = await e.run(command === "status-refresh" ? "status" : command, { configPath:x.configPath, ...(command === "status-refresh" ? {refresh:true} : {}) });
    assert.equal(a.probeCalls, before, "known integrity violation must never enter command probe adapter");
    assert.equal(result.exitCode, 9); assert.equal(result.envelope.error?.code, "s05_deployed_integrity_failed");
  });
}
test("V05 clean Docker without effective group pauses before daemon-dependent effects", async () => {
  const x = await r14Fixture("S04"), o = baseObservation();
  o.dockerGroup = { exists:false,currentUserInGroup:false,accountUserInGroup:false };
  const a = new FakeDockerAdapter(o); a.changeGroupMembership = true;
  const observe = a.observe.bind(a); a.observe = async () => { const o = await observe(); if (!o.dockerGroup.currentUserInGroup) { o.daemonReachable=false; o.apiCompatible=false; o.serverVersion=null; } return o; };
  const e = x.engine([r14Noop("S03"), createDockerStage(a)]); await x.planAndApprove(e);
  const result = await e.run("apply", x.applyOptions);
  assert.equal(result.exitCode, 4, JSON.stringify(result)); assert.equal(a.groupCalls,1); assert.equal(a.restartCalls,0); assert.equal(a.mergeCalls,0);
  assert.equal((await x.state()).in_flight_operation,null); assert.equal((await x.state()).stages.find(s=>s.id==="S04")?.status,"awaiting_manual");
});
test("V08 external Include is explicitly refused rather than silently omitted", async () => {
  const x = await accessInventory("Include /etc/ssh/extra/access.conf\n");
  await x.write("/etc/ssh/extra/access.conf", "Match User factory\n PasswordAuthentication yes\n");
  await assert.rejects(() => observeAccessInputProof(x.adapter,1000,"/manual"), {code:"s03_include_unsupported"});
  assert.equal(x.mutations(),0);
});
