# Independent R1.2 review evidence

Проверенный code SHA: 13f6137e414a563f9f4e152f9145245e175a2d1b.
Baseline сравнения stages: b0bc219fbdf9fd5c7e07496c2c1d6ee4ebb1d3d4.
Дата: 24 октября 2026, Europe/Amsterdam. Node v24.19.0, npm 11.9.0.

## Безопасный scope и интерпретация

Только временная FS, fake adapters, локальные test subprocesses. Real sudo/apt/systemd/SSH/firewall/Docker/OAuth/provider/model/GitHub writes/VM/VPS NOT RUN. Скрипты не меняют исходники репозитория. Helper fixtures некоторых integration tests загружаются из compiled JS в память; их test callbacks не исполняются.

`passed=true`, `defect_reproduced=true` и exit 0 у review probes означают успешное подтверждение описанного поведения pinned source. Для N-case это подтверждение ошибки, **не product PASS**. При исправлении expectations нужно инвертировать на безопасное поведение.

## Содержимое

- r12-review-probes.cjs / .jsonl: четыре positive groups P01…P04 и пять core counterexamples N01…N05. Safe recovery proof генерируется настоящими engine/writer calls, а не вручную нарисованным checkpoint.
- r12-stage-compat-probes.cjs: одинаковые полноценные engine сценарии S03/S04/S05/S07 на двух code trees. Actual stages + fake adapters/prerequisites; guards не отключаются. before/after.jsonl: S04/S07 — новые regressions, S03/S05 — прежние blockers.
- r12-s06-noop-probe.cjs / .jsonl: исправленный fresh no-op реальной S06 через engine.
- r12-lifecycle-controls.cjs / .jsonl: настоящие S00 из default registry, S01 и S02; positive apply/status/resume/repeat controls. Новый engine в том же процессе не считается новым process.
- r12-tests.log: неизменённая штатная suite, 123 passed / 0 failed. Пустой silent typecheck log соответствует exit 0, зафиксированному в review-metadata.json.
- production-source-diff.patch: production diff четырёх TS-файлов. Полные source/tests доступны на pinned SHA.
- copilot-* — входной отчёт и исходное evidence; copilot-node26-validation.log отделён от нашего Node 24 run.
- review-metadata.json: SHA, runtime, результаты и same-fixture comparison.

## Воспроизведение

Создайте отдельные worktrees на двух точных SHA; исходную рабочую ветку не reset/clean. В каждой используйте настоящий Node 24 и выполните:

```bash
npm --prefix setup ci --ignore-scripts --no-audit --no-fund
npm --prefix setup run typecheck --silent
npm --prefix setup run test --silent
```

Все четыре *.cjs принимают абсолютный путь checkout первым аргументом, по умолчанию используют cwd. Поэтому scripts можно хранить вне репозитория. Например, из каталога evidence после сборки указанных worktrees:

```bash
node r12-review-probes.cjs /workspace/scratch/d38639edcc79/agent-factory-review-13f6137
node r12-s06-noop-probe.cjs /workspace/scratch/d38639edcc79/agent-factory-review-13f6137
node r12-lifecycle-controls.cjs /workspace/scratch/d38639edcc79/agent-factory-review-13f6137
node r12-stage-compat-probes.cjs /workspace/scratch/d38639edcc79/agent-factory-review-b0bc219
node r12-stage-compat-probes.cjs /workspace/scratch/d38639edcc79/agent-factory-review-13f6137
```

Это точные пути выполненного review. На другой машине передайте соответствующие абсолютные пути её worktrees. Никакие реальный host credential или daemon для этих scripts не нужны. Сравнивать нужно outcome/error/counters, а не случайные UUID/temp paths.

## Исправления самого review harness

r12-review-probes-first-run.jsonl сохранён для прозрачности. В первом запуске два probe остановились из-за ошибок harness: поле marker-path было перекрыто распарсенным объектом; remove-wrapper не передавал options при удалении lock directory. Оба исправлены только в review script. Неверные ошибки того запуска не являются findings о продукте. Финальный script, финальный .jsonl и все результаты аудита согласованы; исходники продукта не менялись.

## Ограничения

Manifest-only и mixed-generation/quarantine fixtures моделируют потерю/восстановление artifacts, а не утверждают, что штатный engine сам удаляет эти файлы. N05 оставляет неизвестное blocked; он не доказывает false completed. Multi-process K10 проверен штатной suite на одной конкретной границе, не всеми physical crash schedules. Полнота production security неизвестна.
