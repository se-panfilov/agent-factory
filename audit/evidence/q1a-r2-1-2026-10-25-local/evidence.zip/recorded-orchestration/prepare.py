from pathlib import Path
import subprocess,os,hashlib,io,tarfile,json,zipfile
r=Path('/Users/splswrd/work/agent-factory');t=Path('/private/tmp/af-r21');o=r/'audit/evidence/q1a-r2-1-2026-10-25-local';o.mkdir(exist_ok=True)
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env)
names=sorted(set(git('ls-files','setup').decode().splitlines()+git('ls-files','--others','--exclude-standard','setup').decode().splitlines()));deleted=[n for n in names if not(r/n).exists()];m=''.join(hashlib.sha256((r/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names if n not in deleted);(o/'tested-files.sha256').write_text(m);(o/'deletions.json').write_text(json.dumps(deleted)+'\n')
patch=git('diff','--binary','HEAD','--','setup')
for n in git('ls-files','--others','--exclude-standard','setup').decode().splitlines():
 p=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=r,env=env,stdout=subprocess.PIPE);assert p.returncode==1;patch+=p.stdout
(o/'full-local.patch').write_bytes(patch)
f=t/'fixed';f.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive','HEAD'))) as a:a.extractall(f,filter='data')
subprocess.run(['git','apply',str(o/'full-local.patch')],cwd=f,env=env,check=True)
for l in m.splitlines():
 h,n=l.split('  ',1);assert hashlib.sha256((f/n).read_bytes()).hexdigest()==h,n
(t/'reconstruction-before.json').write_text(json.dumps({'match':True,'files':len(names)-len(deleted),'manifest_sha256':hashlib.sha256(m.encode()).hexdigest(),'base':git('rev-parse','HEAD').decode().strip()},indent=2)+'\n')
with zipfile.ZipFile(r/'audit/evidence/q1a-r1-6-2026-10-25-local/evidence.zip') as z:z.extractall(t/'r16-frozen')
history=t/'historical-r15';history.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive','b888082167b5edc50977a6dcda997b40e962da8d'))) as a:a.extractall(history,filter='data')
print(json.dumps({'manifest_files':len(names)-len(deleted),'manifest_sha256':hashlib.sha256(m.encode()).hexdigest()}))
