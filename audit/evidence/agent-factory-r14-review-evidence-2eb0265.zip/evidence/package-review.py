from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'r14-review'
EV = OUT / 'evidence'
HEAD = '2eb026527d3448fc0d455f6fe8713cba61c0d3c5'
BASE = '3e4e07c4ec4bf5ca898025b68520c43c5d9905e3'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT / 'agent-factory'), *args])

def write_json(name, data):
    (EV / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

logs = {
    'r14-npm-ci.log': 'npm-ci.log',
    'r14-typecheck.log': 'typecheck.log',
    'r14-tests.log': 'tests.log',
    'r14-independent-comparison.jsonl': 'comparison.jsonl',
    'r14-independent-comparison.err': 'comparison.stderr',
    'r14-independent-lifecycle.jsonl': 'lifecycle.jsonl',
    'r14-independent-lifecycle.jsonl.stderr': 'lifecycle.stderr',
    'r14-independent-stages.jsonl': 'stages.jsonl',
    'r14-independent-stages.jsonl.stderr': 'stages.stderr',
    'r14-independent-s06.jsonl': 's06.jsonl',
    'r14-independent-s06.jsonl.stderr': 's06.stderr',
    'r14-independent-full-lifecycle.jsonl': 'full-lifecycle.jsonl',
    'r14-independent-full-lifecycle.err': 'full-lifecycle.stderr',
}
for src, dst in logs.items():
    shutil.copyfile(ROOT / src, EV / dst)

inputs = EV / 'input-r14'
inputs.mkdir(exist_ok=True)
shutil.copyfile(ROOT / 'upload/remediation-q1a-r1-4-2026-10-24.md', inputs / 'report.md')
for name in ['identity.json', 'validation-summary.json', 'comparison-assertions.json', 'acceptance-mapping.json', 'patch-reconstruction.json', 'SHA256SUMS']:
    shutil.copyfile(ROOT / 'r14-input-evidence' / name, inputs / name)
for name in ['r14-comparison.cjs', 'full-lifecycle.cjs', 'lifecycle-controls.cjs', 'stage-compat-probes.cjs', 's06-noop-probe.cjs']:
    target = inputs / 'runners' / name
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(ROOT / 'r14-input-evidence/runners' / name, target)
shutil.copytree(ROOT / 'r14-input-evidence/frozen-fixtures', inputs / 'frozen-fixtures', dirs_exist_ok=True)

source_archive = ROOT / 'upload/agent-factory-q1a-r1-4-evidence-2026-10-24.zip'
assert digest(source_archive.read_bytes()) == 'bd0bee8b8798e0cec3b26a4658b22f61f6e1a18a5a72c9a5f640a3716d14dae4'
checked = []
with zipfile.ZipFile(source_archive) as z:
    assert z.testzip() is None
    checksums_name = next(n for n in z.namelist() if n == 'SHA256SUMS' or n.endswith('/SHA256SUMS'))
    prefix = checksums_name[:-len('SHA256SUMS')]
    for line in z.read(checksums_name).decode().splitlines():
        if not line.strip():
            continue
        expected, name = line.split(maxsplit=1)
        name = name.lstrip('*')
        assert digest(z.read(prefix + name)) == expected, name
        checked.append(name)
write_json('input-checksums-verification.json', {'zip_sha256': digest(source_archive.read_bytes()), 'zip_crc': 'PASS', 'verified_entries': len(checked), 'all_entry_hashes': 'PASS'})

assert git('rev-parse', 'origin/master').decode().strip() == HEAD
diff_files = git('diff', '--name-only', '4c28f49228a01a0cb4e8f25a7504883c90ea8672', HEAD).decode().splitlines()
assert len(diff_files) == 3 and all(p.startswith(('audit/evidence/', 'docs/audits/')) for p in diff_files)
(EV / 'source-diff.patch').write_bytes(git('diff', '--binary', BASE, HEAD, '--', 'setup/src', 'setup/tests', 'setup/docs'))
(EV / 'changed-files.txt').write_bytes(git('diff', '--name-status', BASE, HEAD))

files = git('ls-tree', '-r', '--name-only', HEAD).decode().splitlines()
source_hashes = []
snapshot = ROOT / 'agent-factory-review-2eb0265'
for name in files:
    expected = git('show', HEAD + ':' + name)
    actual = (snapshot / name).read_bytes()
    assert actual == expected, 'Tracked source changed during review: ' + name
    source_hashes.append(f'{digest(actual)}  {name}')
(EV / 'reviewed-files.sha256').write_text('\n'.join(source_hashes) + '\n')
write_json('identity.json', {
    'report_date': '2026-10-25', 'report_timezone': 'Europe/Amsterdam',
    'repository': 'https://github.com/se-panfilov/agent-factory',
    'baseline_commit': BASE, 'reviewed_master': HEAD,
    'master_tree': git('rev-parse', HEAD + '^{tree}').decode().strip(),
    'copilot_tested_code_commit': '4c28f49228a01a0cb4e8f25a7504883c90ea8672',
    'packaging_only_difference': diff_files,
    'snapshot_method': 'git archive master into new ordinary filesystem directory; no branch/worktree created',
    'all_tracked_snapshot_files_equal_commit': True, 'tracked_file_count': len(files),
    'node': subprocess.check_output(['node', '--version']).decode().strip(),
    'npm': subprocess.check_output(['npm', '--version']).decode().strip(),
    'platform': 'Linux x86_64',
    'real_privileged_or_external_effects': 0,
    'product_source_changes_by_reviewer': 0, 'commits_push_branches_prs_by_reviewer': 0,
    'original_working_tree': 'Preserved, including pre-existing untracked application self-test fixture',
})

rows = [json.loads(l) for l in (EV / 'comparison.jsonl').read_text().splitlines()]
c = {r['id'][:3]: r for r in rows if r['id'].startswith('C')}
assert len(c) == 12 and all(r['harness_ok'] for r in c.values())
assert all(x['recover']['exit'] == x['retry']['exit'] == 0 and x['last_effect_checkpoint_after'] is not None for x in c['C01']['cases'])
assert c['C02']['recover']['exit'] == 8 and c['C02']['history_preserved']
assert c['C03']['recover']['exit'] == c['C03']['plan']['exit'] == 8 and c['C03']['manifest_preserved'] and not c['C03']['primary_exists']
assert c['C04']['recover']['exit'] == c['C04']['plan_exit'] == c['C04']['next_apply']['exit'] == 8 and c['C04']['readonly_evidence_unchanged']
assert c['C05']['apply_exit'] == 6 and c['C05']['recover']['exit'] == 8
assert sum(e['phase'] == 'checkpoint' for e in c['C05']['traces'][-1]['journal']) == 2
assert c['C06']['probe_calls'] >= 1 and c['C06']['apply_exit'] == 5 and c['C06']['recorded_status'] != 'verified'
assert c['C07']['apply']['exit'] == 4 and c['C07']['resume_evidence']['old_session']['exit'] == 4
assert c['C07']['resume_evidence']['active_session']['exit'] == c['C07']['resume_evidence']['repeat']['exit'] == 0
assert c['C08']['rollback_calls'] == 1 and c['C08']['disarm_calls'] == 0
assert c['C09']['recover']['exit'] == 8 and not any(c['C09'][k] for k in ['primary_written', 'manifest_changed', 'decision_changed'])
assert all(x['apply']['exit'] == 0 and x['apply_calls'] == 0 for x in c['C10']['cases'])
assert c['C11']['apply_exit'] == 4 and c['C11']['inflight'] is None and c['C11']['engine_cutover_calls'] == c['C11']['engine_stage_calls'] == 0
assert c['C12']['retry']['exit'] == 8 and c['C12']['evidence_preserved']

new = [json.loads(l) for l in (EV / 'new-probes.jsonl').read_text().splitlines() if json.loads(l)['id'] != 'META']
assert len(new) == 6 and all(r['harness_ok'] for r in new)
assert sum(r['acceptance'] for r in new) == 1
log = (EV / 'tests.log').read_text()
assert 'tests 254' in log and 'pass 254' in log and 'fail 0' in log
matrix = {}
for marker in ['R14_FAULT', 'R14_CRASH', 'R14_RECOVERY_FAULT']:
    values = [json.loads(line.split(marker + ' ', 1)[1]) for line in log.splitlines() if marker + ' ' in line]
    matrix[marker] = len(values)
    write_json(marker.lower() + '.json', values)
assert matrix == {'R14_FAULT': 36, 'R14_CRASH': 10, 'R14_RECOVERY_FAULT': 4}
write_json('independent-validation.json', {
    'npm_ci': 0, 'typecheck': 0, 'tests': {'pass': 254, 'fail': 0, 'skipped': 0},
    'old_comparison_cases_checked_against_corrected_expectations': 12,
    'matrix_records_within_same_suite': matrix, 'u05_tests': 56,
    'new_cases': 6, 'positive_contract_control_pass': 1,
    'negative_counterexamples_reproduced': 5, 'findings': ['R14-F01', 'R14-F02', 'R14-F03'],
    'package_verdict': 'PARTIAL', 'production_verdict': 'OPEN',
    'not_run': ['VM', 'real sudo/apt/systemd/SSH/firewall/Docker', 'OAuth', 'paid provider/model calls', 'GitHub writes', 'physical power loss'],
    'harness_note': 'Initial formatter error log retained; only corrected new-probes.jsonl is assessed',
})

included = [p for p in OUT.rglob('*') if p.is_file() and p.suffix not in ['.zip', '.sha256'] and p.name != 'SHA256SUMS']
# Include the reviewed source hash manifest even though its suffix is .sha256.
included.append(EV / 'reviewed-files.sha256')
included = sorted(set(included))
sums = OUT / 'SHA256SUMS'
sums.write_text(''.join(f'{digest(p.read_bytes())}  {p.relative_to(OUT).as_posix()}\n' for p in included))
included.append(sums)
zip_path = OUT / 'agent-factory-r14-review-evidence-2eb0265.zip'
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(included):
        info = zipfile.ZipInfo(p.relative_to(OUT).as_posix(), date_time=(2026, 10, 25, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, p.read_bytes())
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS').decode().splitlines():
        expected, name = line.split(maxsplit=1)
        assert digest(z.read(name)) == expected
hash_value = digest(zip_path.read_bytes())
zip_path.with_name(zip_path.name + '.sha256').write_text(f'{hash_value}  {zip_path.name}\n')
print(json.dumps({'zip': str(zip_path), 'sha256': hash_value, 'entries': len(included), 'bytes': zip_path.stat().st_size, 'tracked_source_files_verified': len(files)}))
