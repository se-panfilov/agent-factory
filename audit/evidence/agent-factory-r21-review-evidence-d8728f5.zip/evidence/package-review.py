"""Package this completed review with checked inputs; never mutate the product repository."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parents[2]
out = root/'r21-review'
evidence = out/'evidence'
repo = root/'agent-factory'
snapshot = root/'agent-factory-review-d8728f5'
reconstructed = root/'agent-factory-r21-reconstructed'
incoming = root/'r21-input-evidence'
master = 'd8728f56e847a9da75b9f21d8e6e6725a9bd295e'
digest = lambda data: hashlib.sha256(data).hexdigest()
verified_inputs = []
for line in (incoming/'SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert digest((incoming/name).read_bytes()) == expected, name
    verified_inputs.append(name)
manifest = incoming/'bundle/tested-files.sha256'
files = []
for line in manifest.read_text().splitlines():
    expected, name = line.split('  ', 1)
    assert digest((snapshot/name).read_bytes()) == expected, name
    assert digest((reconstructed/name).read_bytes()) == expected, name
    files.append(name)
tracked = subprocess.check_output(['git','ls-tree','-r','--name-only',master,'setup'],cwd=repo,text=True).splitlines()
assert set(tracked) == set(files)
archive = subprocess.check_output(['git','archive',master],cwd=repo)
tracked_count = 0
with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
    for member in stream.getmembers():
        if member.isfile():
            assert stream.extractfile(member).read() == (snapshot/member.name).read_bytes(), member.name
            tracked_count += 1
for source, target in [('remediation-q1a-r2-1-2026-10-25.md','report.md'),
                       ('full-local(2).patch','full-local.patch'),('tested-files.sha256','tested-files.sha256'),
                       ('evidence(3).zip','evidence.zip'),('evidence.zip(3).sha256','evidence.zip.sha256')]:
    assert (root/'upload'/source).read_bytes() == (snapshot/'audit/evidence/q1a-r2-1-2026-10-25-local'/target).read_bytes()
assert (incoming/'runners/r2-admission-probes.cjs').read_bytes() == (root/'r16-review/evidence/r2-admission-probes.cjs').read_bytes()
assert all(row['exit_code'] == 0 for row in json.loads((evidence/'validation/commands.json').read_text()))
suite = (evidence/'validation/tests.log').read_text()
assert 'tests 429' in suite and 'pass 429' in suite and 'fail 0' in suite
for name, count in [('comparison-assertions.json',33),('command-assertions.json',37),('r2-product-assertions.json',39)]:
    assert len(json.loads((evidence/'comparisons'/name).read_text())) == count
for label in ['baseline','fixed']:
    rows = [json.loads(line) for line in (evidence/f'access-continuation-{label}.jsonl').read_text().splitlines()]
    assert len(rows) == 14 and rows[-1]['cases'] == 13 and rows[-1]['acceptance_pass'] == 3
    assert not (evidence/f'access-continuation-{label}.stderr').read_bytes()
remote = subprocess.check_output(['git','ls-remote','origin','refs/heads/master'],cwd=repo,text=True).split()[0]
assert remote == master, 'Remote changed; report the exact reviewed version before claiming current master.'
verification = {'reviewed_commit':master,'remote_master_at_packaging':remote,'tracked_snapshot_files_exact':tracked_count,
                'incoming_checksums_verified':len(verified_inputs),'manifest_files_verified':len(files),
                'manifest_exact_tracked_setup_coverage':True,'reconstructed_master_setup_match':True,
                'all_five_attachments_match_master':True,'original_r2_runner_unchanged':True,
                'final_tests':{'pass':429,'fail':0,'skip':0},'new_s03_cases_per_tree':13,'new_s03_desired_pass_per_tree':3,
                'new_s03_desired_fail_per_tree':10,
                'owner_checkout_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
                'owner_checkout_status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True),
                'notes':'Only final S03 runs count; old overlap and initial harness error are retained separately. No product source edits.'}
(evidence/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
payload = [(p.relative_to(out).as_posix(),p) for p in out.rglob('*')
           if p.is_file() and p.suffix not in ['.zip','.sha256'] and '__pycache__' not in p.parts]
payload += [('incoming/'+p.relative_to(incoming).as_posix(),p) for p in incoming.rglob('*') if p.is_file()]
payload.sort()
assert len(payload) == len({name for name,p in payload})
sums = ''.join(f'{digest(p.read_bytes())}  {name}\n' for name,p in payload).encode()
target = out/'agent-factory-r21-review-evidence-d8728f5.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in payload:z.write(p,name)
    z.writestr('SHA256SUMS',sums)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS').decode().splitlines():
        expected,name=line.split('  ',1);assert digest(z.read(name)) == expected
    for name in ['agent-factory-r21-audit-d8728f5.ru.md','copilot-q1a-r2-1-1-task.ru.md','README.md']:
        assert z.read(name) == (out/name).read_bytes()
checksum = digest(target.read_bytes())
Path(str(target)+'.sha256').write_text(f'{checksum}  {target.name}\n')
print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'entries':len(payload)+1,
                  'sha256':checksum,'verification':verification},indent=2))
