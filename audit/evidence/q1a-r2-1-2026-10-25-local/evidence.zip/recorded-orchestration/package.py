from pathlib import Path
import os,hashlib,subprocess,json,tarfile,io,shutil,platform,re
r=Path('/Users/splswrd/work/agent-factory');t=Path('/private/tmp/af-r21');o=r/'audit/evidence/q1a-r2-1-2026-10-25-local';stage=t/'package';stage.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env)
report='docs/audits/remediation-q1a-r2-1-2026-10-25.md';shutil.copy2(r/report,o/'report.md');new=git('ls-files','--others','--exclude-standard','setup',report).decode().splitlines();patch=git('diff','--binary','HEAD','--','setup')
for n in new:
 result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=r,env=env,stdout=subprocess.PIPE);assert result.returncode==1;patch+=result.stdout
(o/'full-local.patch').write_bytes(patch);(o/'new-files.json').write_text(json.dumps([{'path':n,'sha256':sha(r/n)} for n in new],indent=2)+'\n')
with tarfile.open(o/'new-files.tar','w',format=tarfile.PAX_FORMAT) as tar:
 for n in sorted(new):
  data=(r/n).read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
initial=json.loads((t/'initial.json').read_text());commands=json.loads((t/'final-validation/commands.json').read_text());assert len(commands)==5 and all(x['exit_code']==0 for x in commands)
identity={'base_commit':initial['head'],'base_tree':initial['tree'],'branch':initial['branch'],'audited_base_commit':'5fde93d2c470171039698c35478c020085ef66ff','audited_base_tree':'f8bca0179c0ce0f583c947a6d53e9852f38fba89','tested_commit':None,'tested_tree_identity':'sha256-manifest:'+sha(o/'tested-files.sha256'),'tested_manifest_sha256':sha(o/'tested-files.sha256'),'tested_files':143,'patch_sha256':sha(o/'full-local.patch'),'new_files_tar_sha256':sha(o/'new-files.tar'),'report_sha256':sha(o/'report.md'),'initial_owner_layer':{'status':initial['status'],'changes':[],'staged_patch':'logs/staged.patch','unstaged_patch':'logs/unstaged.patch'},'index_sha256_before':initial['index_sha256'],'index_sha256_after':sha(r/'.git/index'),'node':(t/'final-validation/node.log').read_text().strip(),'npm':(t/'final-validation/npm.log').read_text().strip(),'os':platform.platform(),'arch':platform.machine(),'uid':os.getuid(),'validation_commands':commands,'comparison_commands':json.loads((t/'comparison-commands.json').read_text()),'reconstruction':'git archive actual base into empty ordinary temporary directory; empty owner layer; git apply full-local.patch without index; verify tested-files/new-files/deletions. Additions already in full patch; tar is redundant. Packaging is separate.','manifest_exclusions':['node_modules','dist','.git','audit/report/packaging','temporary outputs/secrets'],'production':'OPEN','R2_2':'OPEN','real_host_qualification':'NOT RUN','agent_commit_push_branch_worktree_pr_tag_release_deploy':False}
(o/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for l in (o/'tested-files.sha256').read_text().splitlines():
 h,n=l.split('  ',1);assert sha(r/n)==sha(t/'fixed-release'/n)==h,n
assert sha(r/'.git/index')==initial['index_sha256'];assert git('rev-parse','HEAD').decode().strip()==initial['head'];assert git('branch','--show-current').decode().strip()==initial['branch']
(t/'final-repository-state.json').write_text(json.dumps({'head':initial['head'],'branch':initial['branch'],'index_sha256':sha(r/'.git/index'),'head_unchanged':True,'branch_unchanged':True,'index_bytes_unchanged':True,'owner_layer_empty':True,'status':git('status','--porcelain=v1').decode(),'no_agent_commit_push_branch_worktree_pr_tag_release_deploy':True},indent=2)+'\n')
(t/'base-delta.json').write_text(json.dumps([{'path':n,'sha256':sha(r/n)} for n in git('diff','--name-only','5fde93d2c470171039698c35478c020085ef66ff','HEAD').decode().splitlines()],indent=2)+'\n')
log=(t/'final-validation/tests.log').read_text();assert 'ℹ pass 429' in log and 'ℹ fail 0' in log
names=[re.sub(r' \([0-9.]+ms\)$','',l[2:]) for l in log.splitlines() if l.startswith('✔ ')]
for tag,name in [('R21_TAMPER','policy-tamper-matrix'),('R21_TIME','time-matrix'),('R21_PROGRESS','progress-matrix'),('R21_PROCESSES','subprocess-matrix'),('R14_FAULT','r14-manifest-faults'),('R14_CRASH','r14-crashes'),('R14_RECOVERY_FAULT','recovery-faults'),('R15_DOCKER_FAULT','r15-docker-faults'),('R15_DOCKER_CRASH','r15-docker-crashes'),('R16_REAL_COMMAND','r16-real-commands'),('R16_REFUSAL','r16-refusals'),('R16_PROBE_CONTROL','r16-probe-controls')]:
 rows=[json.loads(l.split(' ',1)[1]) for l in log.splitlines() if l.startswith(tag+' ')];(t/(name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
accept=[]
for i in range(1,15):
 id=f'A21-{i:02d}';token=f'{i:02d}';selected=[n for n in names if n.startswith('A21-') and token in n.split(' ',1)[0][4:].split('/')]
 if i==8:selected += [n for n in names if n.startswith(('U01 ','U02 ','U06 ','V06 ','V07 '))]
 if i==14:selected=['All previous 397 tests retained in full 429-test log','33 frozen assertions PASS','37 command assertions PASS (overlap noted)','Exact reconstruction before/after and final patch match; HEAD/branch/index preserved']
 assert selected,id
 accept.append({'id':id,'status':'PASS','scope':'local only; R2.2/production OPEN','assertions':selected,'source':'setup/tests/integration/q1a-r21-admission.test.ts' if i!=14 else 'all retained tests/checkers + packaging','log':'logs/final-validation/tests.log'})
(t/'acceptance-matrix.json').write_text(json.dumps(accept,indent=2)+'\n')
# Red layer is the actual pre-production-edit source, not today's expanded passing test file.
p=stage/'red-layer/setup/tests/integration/q1a-r21-admission.test.ts';p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(t/'red/setup/tests/integration/q1a-r21-admission.test.ts',p)
shutil.copytree(t/'runners',stage/'runners',dirs_exist_ok=True);shutil.copytree(t/'r16-frozen/inputs',stage/'inputs',dirs_exist_ok=True)
shutil.copy2(r/'audit/reviews/agent-factory-r16-audit-5fde93d.ru.md',stage/'inputs/r16-audit.md');shutil.copy2(r/'audit/copilot-q1a-r2-1-task.ru.md',stage/'inputs/r21-task.md')
(t/'original-r2-runner-identity.json').write_text(json.dumps({'original_sha256':sha(t/'input/evidence/r2-admission-probes.cjs'),'included_sha256':sha(t/'runners/r2-admission-probes.cjs'),'unchanged':(t/'input/evidence/r2-admission-probes.cjs').read_bytes()==(t/'runners/r2-admission-probes.cjs').read_bytes()},indent=2)+'\n')
print(json.dumps({'files':143,'new_files':len(new),'manifest':identity['tested_manifest_sha256'],'patch':identity['patch_sha256']}))
