const path=require('path'),{getEventListeners}=require('events');
const base=path.join(process.argv[2],'setup/dist/src');
const {NodeProcessAdapter}=require(path.join(base,'adapters/process.js'));
const {executionScope,RunLifecycle}=require(path.join(base,'adapters/process-lifecycle.js'));
(async()=>{const scope=new RunLifecycle(),signal=new AbortController();let result=null,error=null;
try{result=await executionScope.run(scope,()=>new NodeProcessAdapter().runCommand({policy:'interruptible',binary:process.execPath,args:['-e','process.exit(0)','x'.repeat(200000)],signal:signal.signal,timeoutMs:500,maxOutputBytes:64}));}catch(e){error={name:e.name,code:e.code,exitCode:e.exitCode??null,message:e.message}}
console.log(JSON.stringify({id:'Q1B-REVIEW-SPAWN-SYNC',result,error,registeredProcesses:[...scope.processes.values()],explicitAbortListeners:getEventListeners(signal.signal,'abort').length,scopeAbortListeners:getEventListeners(scope.controller.signal,'abort').length,cleanupUnknown:scope.cleanupUnknown}));
const direct=new AbortController();let directError;try{await new NodeProcessAdapter().runCommand({policy:'interruptible',binary:process.execPath,args:['-e','process.exit(0)','x'.repeat(200000)],signal:direct.signal,timeoutMs:500,maxOutputBytes:64})}catch(e){directError=e.code};console.log(JSON.stringify({id:'Q1B-REVIEW-SPAWN-SYNC-NOSCOPE',error:directError,listeners:getEventListeners(direct.signal,'abort').length}));})();
