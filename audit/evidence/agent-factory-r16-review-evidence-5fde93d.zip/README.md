# R1.6 independent review and next R2 work

Date: 2026-10-25. Reviewed master `5fde93d2c470171039698c35478c020085ef66ff`.

**R1.6 local scope PASS; R15-F01 closed. Production/Q1A OPEN.** Next task: R2.1. Two older plan-admission problems were reproduced on both `b888082` and `5fde93d`; they are not introduced by R1.6.

Read `agent-factory-r16-audit-5fde93d.ru.md` and give `copilot-q1a-r2-1-task.ru.md` to the implementation agent. No commits, push, branches/worktree/PR or deploy; all implementation changes stay local.

## Evidence

- `evidence/input/`: unchanged current attachments (renamed for unambiguous handling), package identity and tested manifest. The input ZIP retains its own runners/frozen fixtures/patch/checksums.
- `evidence/identity-verification.json`: independent byte identity, reconstructed tree, Git source comparison and environment.
- `evidence/validation/`: independent npm/typecheck/397-test run and extracted R14/R15/R16 machine rows.
- `evidence/commands/`: unchanged original W01…W04 runner outputs for baseline/fixed and adapter/stage modes; 37 checker assertions, including one aggregate for the 33 old comparisons.
- `evidence/comparison/`: independent frozen R1.5 comparisons with 33 product assertions.
- `evidence/r2-admission-probes.cjs`: new reviewer-only plan admission tests, no real privileged/network commands.
- `evidence/r2-admission*.jsonl`: new R2 probe outputs on both versions; five safe and three unsafe outcomes per version.
- `evidence/source/`: relevant exact source/contract excerpts and R1.6 production diff.
- `evidence/SHA256SUMS`: all payload checksums except itself.

## Reproduction

Use isolated ordinary repository exports, Node major24 and no credentials. Build the reviewed snapshot in a separate directory:

```text
npm --prefix setup ci --ignore-scripts --no-audit --no-fund
npm --prefix setup run typecheck --silent
npm --prefix setup run test --silent
```

From this unpacked bundle, substitute the absolute compiled snapshot path:

```text
node evidence/r2-admission-probes.cjs /absolute/path/to/snapshot
```

R2A01: valid S02 approvals, exit0, each fake APT effect once. R2A02: no approvals, exit4, zero effects. **R2A03: removing both gate lists and recomputing self-hash currently produces exit0 and all three fake effects without approvals.** R2A04 one-sided removal and R2A05 incorrect hash correctly refuse. R2A06 fresh gate-free synthetic stage succeeds. **R2A07 at31min and R2A08 with a creation time in the future also execute, incorrectly.** `harness_ok`/exit0 is not product acceptance; inspect each `acceptance` field.

S02 probe uses the real engine/producer with an explicitly fake AptAdapter. The temporal probe uses the real engine, injected clock and synthetic low-risk stage. ProcessAdapter refuses all actual process commands. Nothing calls sudo, apt, systemd, SSH, UFW, Docker daemon, models or remote services. The same eight outcomes occur on baseline `b888082` and fixed `5fde93d`.

The original R1.6 review tests can be rerun by safely extracting `evidence/input/copilot-r16-evidence.zip` to another directory. Its README explains reconstruction from `420e5456 + full-local.patch` and final validation. The full patch includes new files; `new-files.tar` is an alternative payload, not an additional overlay. Its `runners/command-measurements.py`, `run-evidence.py`, `check-results.py` and `check-r16.py` were inspected and independently rerun. Baseline setup code at `420e5456` equals `b888082`.

No production code was edited during review. The auditor runtime is Linux x86_64/Node v24.22.1/npm11.9.0/UID0; Copilot's original runtime was macOS arm64/Node v24.12.0/UID501. These are local test environments, not target host qualification. R1.6 tests run only owned stdout/argv children; dangerous option negatives stop before execution.

NOT RUN: real privileged host effects, Docker daemon/cgroups, VM/VPS, credentials/OAuth/provider/model calls, GitHub writes, deploy/release or physical power loss. SSH cutover/rollback and privileged executor code blockers remain open.

The packaging script records the auditor workspace operations and expects its original inputs. It is not needed for running the portable probes or checking ZIP integrity. A checksum proves byte identity, not security correctness.
