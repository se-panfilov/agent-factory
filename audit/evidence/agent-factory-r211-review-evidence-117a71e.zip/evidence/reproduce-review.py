"""Reproduce the exact R2.1.1 review locally, without Git mutations or host effects."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo', required=True, type=Path, help='Existing clone with the recorded Git objects; never fetched or edited.')
p.add_argument('--work', required=True, type=Path, help='Empty ordinary temporary directory, not a worktree.')
p.add_argument('--resume-prepared', action='store_true', help='Explicitly resume after an incomplete measurement; preserves failed logs and verifies prepared source.')
a = p.parse_args()
repo = a.repo.resolve()
work = a.work.resolve()
package = Path(__file__).resolve().parent.parent
incoming = package / 'incoming'
runners = incoming / 'runners'
if not a.resume_prepared:
    assert not work.exists() or not any(work.iterdir()), 'Work directory must be empty.'
else:
    assert (work/'commands.json').is_file() and not (work/'result.json').exists(), 'No incomplete prepared replay to resume.'
work.mkdir(parents=True, exist_ok=True)
env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}
assert subprocess.check_output(['node', '--version'], text=True).startswith('v24.')
commands = json.loads((work/'commands.json').read_text()) if a.resume_prepared else []
digest = lambda data: hashlib.sha256(data).hexdigest()

def verify_sums(root, file):
    for line in file.read_text().splitlines():
        expected, name = line.split('  ', 1)
        target = (root / name).resolve()
        assert target.is_relative_to(root.resolve()) and target.is_file(), name
        assert digest(target.read_bytes()) == expected, name

verify_sums(incoming, incoming/'SHA256SUMS')

def run(name, argv, cwd=work, expected=0, timeout=240):
    argv = [str(x) for x in argv]
    log = work / 'logs' / name
    log.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    with log.open('w') as stream:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=timeout)
    commands.append({'argv': argv, 'cwd': str(cwd), 'exit_code': result.returncode,
                     'expected_exit': expected, 'elapsed_seconds': round(time.monotonic()-start, 3),
                     'log': str(log.relative_to(work))})
    (work/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert result.returncode == expected, (name, result.returncode, expected)
    print(name, result.returncode, flush=True)
    return log

def archive(commit, name):
    destination = work / name
    destination.mkdir()
    raw = subprocess.check_output(['git', 'archive', commit], cwd=repo, env=env)
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        stream.extractall(destination, filter='data')
    return destination

if not a.resume_prepared:
    base = archive('6281df5796ec5dd82a6fee95b058bbc970f0ed16', 'baseline')
    old_r2 = archive('ca6d0b6f2a75f3c97a80468bbc2bdcbe2db7a4ff', 'old-r2')
    old_command = archive('b888082167b5edc50977a6dcda997b40e962da8d', 'old-command')
    fixed = work/'fixed'
    run('reconstruct.log', ['python3', runners/'reconstruct-r211.py', '--repo', repo,
                            '--bundle', incoming, '--output', fixed])
    # Verify the reconstruction against the published commit, independently of patch self-hashes.
    for line in (incoming/'tested-files.sha256').read_text().splitlines():
        expected, name = line.split('  ', 1)
        published = subprocess.check_output(['git', 'show', '117a71e3607659e97509b99c1662131c3970c112:'+name], cwd=repo, env=env)
        assert digest(published) == expected == digest((fixed/name).read_bytes()), name
    run('validation.log', ['python3', runners/'validate.py', '--checkout', fixed,
                           '--bundle', incoming, '--logs', work/'validation'])
    for label, tree in [('baseline', base), ('old-r2', old_r2), ('old-command', old_command)]:
        run(label+'-ci.log', ['npm', '--prefix', 'setup', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], tree)
        run(label+'-build.log', ['npm', '--prefix', 'setup', 'run', 'build', '--silent'], tree)
    for label, tree, expected in [('baseline', base, 1), ('fixed', fixed, 0)]:
        log = run('access-'+label+'.jsonl', ['node', runners/'access-continuation-probes.cjs', tree])
        run('access-'+label+'-desired.json', ['python3', runners/'check-access-continuation.py', log, '--expect', 'fixed'], expected=expected)
    legacy = run('access-legacy.jsonl', ['node', runners/'access-legacy-transition.cjs', base, fixed])
    run('access-legacy-oracle.json', ['python3', runners/'check-access-continuation.py', legacy, '--expect', 'fixed'])
else:
    base, old_r2, old_command, fixed = (work/name for name in ['baseline','old-r2','old-command','fixed'])
    for sha, tree in [('6281df5796ec5dd82a6fee95b058bbc970f0ed16', base),
                      ('ca6d0b6f2a75f3c97a80468bbc2bdcbe2db7a4ff', old_r2),
                      ('b888082167b5edc50977a6dcda997b40e962da8d', old_command)]:
        paths = subprocess.check_output(['git','ls-tree','-r','--name-only',sha,'setup'],cwd=repo,env=env,text=True).splitlines()
        for name in paths:
            assert subprocess.check_output(['git','show',sha+':'+name],cwd=repo,env=env) == (tree/name).read_bytes(), (sha,name)
    verify_sums(fixed, incoming/'tested-files.sha256')
    prior_suite = (work/'validation/tests.log').read_text()
    assert 'pass 446' in prior_suite and 'fail 0' in prior_suite
    for label in ['fixed','legacy']:
        proof = json.loads((work/'logs'/('access-'+label+('-desired.json' if label=='fixed' else '-oracle.json'))).read_text())
        assert proof['product_pass']==13 and proof['product_fail']==0
    # Rebuild prepared sources before resuming; do not change any source or prior output.
    for label, tree in [('baseline',base),('old-r2',old_r2),('old-command',old_command),('fixed',fixed)]:
        run(label+'-resume-build.log',['npm','--prefix','setup','run','build','--silent'],tree)
comparison_dir = work/('comparisons-resumed' if a.resume_prepared else 'comparisons')
assert not comparison_dir.exists(), 'Do not overwrite earlier measurements.'
run('comparisons-resumed.log' if a.resume_prepared else 'comparisons.log', ['python3', runners/'measure-r21.py', '--baseline', old_r2,
                       '--fixed', fixed, '--historical-command-baseline', old_command,
                       '--inputs', incoming/'inputs', '--logs', comparison_dir])
layer = work/'baseline-test-layer'
run('baseline-regression-driver.log', ['python3', runners/'baseline-regression.py', '--baseline', base,
                                     '--fixed', fixed, '--output', layer, '--logs', work/'regression-baseline'])
for label, tree in [('baseline', layer), ('fixed', fixed)]:
    run('recovery-'+label+'-desired-red.log', ['node', runners/'access-final-recovery.cjs', tree], expected=1)
    measured = run('recovery-'+label+'-measured.jsonl', ['node', runners/'access-final-recovery-measurements.cjs', tree])
    rows = [json.loads(line) for line in measured.read_text().splitlines()]
    assert len(rows) == 2 and {r['mode'] for r in rows} == {'direct', 'plan-first'}
    assert all(r['recover'] == 0 and r['repeat'] == 0 and r['resume'] == 2
               and r['resume_error'] == 'plan_policy_mismatch' and r['explicit_review_resume'] == 0
               and r['before'] == r['after'] and r['checkpoint_retained'] and not r['desired_acceptance'] for r in rows)
for label, tree in [('baseline', base), ('fixed', fixed)]:
    log = run('context-'+label+'.jsonl', ['node', package/'evidence/context-binding-probes.cjs', tree])
    for expectation, expected in [('observed-current', 0), ('fixed', 1)]:
        run('context-'+label+'-'+expectation+'.json', ['python3', package/'evidence/check-context-binding.py',
                                                      log, '--expect', expectation], expected=expected)
verify_sums(fixed, incoming/'tested-files.sha256')
suite = (work/'validation/tests.log').read_text()
assert 'tests 446' in suite and 'pass 446' in suite and 'fail 0' in suite and 'skipped 0' in suite
(work/'result.json').write_text(json.dumps({'reviewed_commit':'117a71e3607659e97509b99c1662131c3970c112',
    'tests_pass':446, 'S03_baseline_desired':'3/13', 'S03_fixed_desired':'13/13', 'S03_legacy_desired':'13/13',
    'supplementary_recovery_desired_fail':4, 'context_desired_pass_per_tree':'2/5',
    'manifest_unchanged':True, 'comparisons_directory':comparison_dir.name, 'explicit_resume':a.resume_prepared, 'real_host_qualification':'NOT RUN'}, indent=2)+'\n')
print('Exact review reproduced. S03 fixes pass; recovery limitation and R2.2 context findings remain explicitly red.')
