import test from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { commandFixture } from "../helpers/r16-commands";

for (const entry of ["runner.cjs", "runner"]) {
  test(`W02/W03 prepared Node entry is the checked absolute deployment file: ${entry}`, async () => {
    const q = await commandFixture(entry); await q.materialize();
    assert.equal(q.schema().ok, true);
    const result = await q.probe();
    assert.equal(result.runnerVerifyHelpOk && result.runnerStopHelpOk, true);
    assert.equal(q.invocations.length, 2);
    for (const call of q.invocations) assert.equal(call.args[0], path.join(q.x.config.paths.application_dir, entry));
  });
}
test("W04 hashed --eval filename is refused before executable child", async () => {
  const q = await commandFixture("--eval"); await q.materialize();
  q.a.release.manifest!.commands.runner_verify = ["node", "--eval", 'process.stdout.write("INLINE_TRAP")', "--"];
  assert.equal(q.schema().ok, true);
  await assert.rejects(q.probe(), {exitCode:9});
  assert.equal(q.invocations.length, 0);
});
