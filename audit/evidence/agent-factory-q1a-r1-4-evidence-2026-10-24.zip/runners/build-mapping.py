#!/usr/bin/env python3
import json,pathlib,sys
r=pathlib.Path(sys.argv[1]);tests=json.loads((r/'test-results.json').read_text())['tests']
def entry(assertion,*prefixes,extra=None):
 matched=[t['name'] for t in tests if any(t['name'].startswith(p) for p in prefixes)]
 if prefixes: assert matched,(assertion,prefixes)
 return {'status':'PASS','scope':'local deterministic validation only','assertion':assertion,'passed_test_names':matched,'additional_evidence':extra or []}
u={
'U01':entry('Approved input/raw content/ownership/diff/manual drift before/between operations blocks all unauthorized cutover; normal own transitions and failed-tailnet rollback retain behavior','U01 '),
'U02':entry('Mandatory S05 probes run; negative/timeout/missing commands cannot verify or checkpoint probe; repeat verify invalidates stage; dependent S06 effects remain zero','U02 '),
'U03':entry('Engine-generated plan/apply/plan direct and marker-first restore preserves final/checkpoint proof, is idempotent and never repeats effect','U03 '),
'U04':entry('Real S02 refresh/simulation receipts and bound checkpoints precede install; late exception and child interruption retain unknown current attempt and never verify partial stage','U04 '),
'U05':entry('56 phase/contradiction combinations preserve exact primary/previous/manifest/journal/decision bytes and quarantine, with no new effects','U05 '),
'U06':entry('Initially absent packages/group/account/session: install/group durable pause; old session blocked before intent; active new session resumes/repeats without reinstall; unmanaged matching Docker refused','U06 '),
'U07':entry('36 fresh-fixture manifest initial/operation-binding/final paths: write ENOSPC, file-fsync/rename/dir-fsync EIO before/after boundary and fault-off controls, exact hit and typed errors, no unknown replay','U07 ',extra=['manifest-fault-matrix.json']),
'U08':entry('Ten real engine S02 child barriers with bounded IPC, readers byte-identical, foreign lock exit7, own SIGKILL, lock-only state preservation and real-S02 restart; four clean metadata predecessor recovery fault controls','U04 U08 ','U08 engine ',extra=['child-crash-matrix.json','recovery-fault-matrix.json']),
'U09':entry('All actual S00-S07 modules in one engine apply/status/resume with explicit synthetic existing-M0/active-group fixture; separate per-stage controls and accurate S00-S14 route inventory','J01 ','J02 ','K08 ',extra=['full-lifecycle-fixed.log','clean-fixed/stages.log','clean-fixed/lifecycle.log','clean-fixed/s06.log','docs/stage-inventory.md']),
'U10':entry('Stale/newer/manifest-only, malformed receipts, no-op/verify-only/S06, owner/root/lock/gates/read-only/cancel guards retained','K01 ','K07 ','K09 ','K08 ','J03 ','J10 ','R1-01 ','T04 ','T05 '),
'U11':entry('Immutable historical R11/R12/R13 mapping and explicit correction note; every PASS points to a concrete assertion/test or recorded external product check',extra=['acceptance-mapping.json','comparison-assertions.json']),
'U12':entry('Real Node24 commands against exact clean code archive; patch reconstructs every tracked file; full logs, identical comparison runner/frozen fixtures and deterministic ZIP/checksum',extra=['identity.json','patch-reconstruction.json','clean-fixed/commands.json','clean-baseline/commands.json','SHA256SUMS'])}
k={
'K01':entry('Stale primary cannot override committed generation','K01 '),'K02':u['U03'],'K03':u['U07'],
'K04':entry('Prepared decision remains immutable under previous/current substitution and phase conflicts','K04 ','U05 '),
'K05':entry('Missing primary with legacy/unknown evidence is never fresh; newer uncertainty is preserved','K05 ','T04 ','T05 '),
'K06':entry('Typed manifest/restore errors preserve evidence; defined partial restore resumes or remains honestly unresolved','J06 ','J07 ','J09 ','U08 engine '),
'K07':entry('Receipt missing/duplicate/foreign/unplanned/stage/resource mismatches and invalid journal attempt ordering are refused','K07 ','J03 ','J04 '),
'K08':u['U09'],'K09':entry('Empty/verify-only and actual S06 no-op never invoke effectful apply','K09 ','K08 '),
'K10':entry('Original interrupted writer control plus new operation/binding/final/recovery boundaries; unknown outcomes never replay','K10 ','U04 U08 '),
'K11':entry('Regression controls retain cancellation/read-only/lock and fresh safe initialization behavior','J08 ','J10 ','R1-12 '),'K12':u['U12']}
t={'T01':entry('Same frozen C01-C12 fixtures measured on baseline/fixed with product assertions, plus S03/S04/S05/S07 producer controls',extra=['comparison-assertions.json','clean-baseline/comparison.log','clean-fixed/comparison.log','clean-fixed/stages.log']),
'T02':u['U09'],'T03':u['U04'],'T04':entry('Newer unknown manifest cannot be covered by an older checkpoint','T04 '),'T05':entry('Manifest-only/malformed/foreign evidence never initializes fresh','T05 '),'T06':u['U05'],'T07':u['U03'],'T08':u['U07'],'T09':k['K06'],'T10':u['U08'],'T11':k['K09'],'T12':u['U12']}
def finding(meaning,evidence): return {'meaning':meaning,**evidence}
f={
'R11-F01':finding('stale primary / committed generation',k['K01']),
'R11-F02':finding('recovery evidence / immutable prepared decision',u['U05']),
'R11-F03':finding('receipt admission / journal execution protocol',k['K07']),
'R11-F04':finding('no-op / verify-only and S06',k['K09']),
'R11-F05':finding('typed persistence errors',k['K06']),
'R11-F06':finding('evidence/coverage/packaging',u['U12']),
'R12-F01':finding('producer/engine alignment',t['T01']),
'R12-F02':finding('uniform recovery evidence rules',u['U05']),
'R12-F03':finding('plan-written marker blocks proven recovery',u['U03']),
'R12-F04':finding('durable operation progress',u['U04']),
'R12-F05':finding('evidence/mapping discipline',u['U11']),
'R13-F01':finding('S03 input drift guard regression',u['U01']),
'R13-F02':finding('engine-generated checkpoint/final-state recovery regression',u['U03']),
'R13-F03':finding('S05 mandatory probes skipped',u['U02']),
'R13-F04':finding('incomplete all-evidence admission',u['U05']),
'R13-F05':finding('clean S04 group prerequisite cycle',u['U06']),
'R13-F06':finding('inaccurate tests/inventory/acceptance claims',u['U11'])}
full=[json.loads(s) for s in (r/'full-lifecycle-fixed.log').read_text().splitlines() if s.startswith('{')][0]
assert full['status']=='PASS' and full['stage_closure']==['S00','S01','S02','S03','S04','S05','S06','S07']
result={'identity':json.loads((r/'identity.json').read_text()),'findings':f,'K':k,'T':t,'U':u,
 'overall_q1a':'OPEN','real_host_qualification':'NOT RUN',
 'remaining_blockers':['Existing NodeAccessAdapter host cutover is unimplemented and timer/rollback are local markers: explicit Q2 prerequisite, not live SSH/firewall qualification','No real reviewed M0 release or production/VM/privileged qualification is established by synthetic fixtures','Unknown effects and legacy prepared decisions without exact source-manifest proof require owner-reviewed reconciliation','Physical power loss and full process-tree cancellation are not covered; R2/R3/Q1B are not started']}
(r/'acceptance-mapping.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('Mapped',len(f),'findings,',len(k)+len(t)+len(u),'K/T/U criteria to assertions')
canonical={
 'R11-F01':'stale primary / committed generation','R11-F02':'recovery evidence / immutable prepared decision',
 'R11-F03':'receipt admission / journal execution protocol','R11-F04':'no-op / verify-only and S06',
 'R11-F05':'typed persistence errors','R11-F06':'evidence/coverage/packaging',
 'R12-F01':'producer/engine alignment','R12-F02':'uniform recovery evidence rules',
 'R12-F03':'plan-written marker blocks proven recovery','R12-F04':'durable operation progress','R12-F05':'evidence/mapping discipline',
 'R13-F01':'S03 input drift guard regression','R13-F02':'engine-generated checkpoint/final-state recovery regression',
 'R13-F03':'S05 mandatory probes skipped','R13-F04':'incomplete all-evidence admission',
 'R13-F05':'clean S04 group prerequisite cycle','R13-F06':'inaccurate tests/inventory/acceptance claims'}
assert set(f)==set(canonical)
for key,meaning in canonical.items(): assert f[key]['meaning']==meaning,(key,meaning)
assert set(k)=={f'K{i:02}' for i in range(1,13)} and set(t)=={f'T{i:02}' for i in range(1,13)} and set(u)=={f'U{i:02}' for i in range(1,13)}
for section in [f,k,t,u]:
 for key,value in section.items(): assert value['assertion'] and (value['passed_test_names'] or value['additional_evidence']),key
(r/'mapping-check.json').write_text(json.dumps({'status':'PASS','finding_ids_checked':17,'criteria_checked':36,'meaning_check':'immutable R11/R12/R13 canonical table','evidence_check':'every PASS has concrete assertion and actual passed tests or explicit external assertion artifacts'},indent=2)+'\n')
