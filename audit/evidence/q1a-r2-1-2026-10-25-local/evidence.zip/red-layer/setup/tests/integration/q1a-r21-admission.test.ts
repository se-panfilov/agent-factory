import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import { r14Fixture, r14Noop, r14Process } from "../helpers/r14-engine";
import { SetupEngine } from "../../src/core/engine";
import { createRegistry } from "../../src/core/plan";
import { stableStringify } from "../../src/core/config";
import { createSystemStage } from "../../src/stages/system";
import { type InstallerPlan } from "../../src/core/types";

export async function aptFixture() {
  const x = await r14Fixture("S02"), counts = {refresh:0,simulate:0,install:0};
  let fresh = false, installed = false, now = Date.parse("2026-10-25T10:00:00.000Z");
  const clock = {now: () => new Date(now)};
  const apt = {observe: async (names: string[]) => ({metadataFresh:fresh,metadataUpdatedAt:fresh?"2026-10-25T10:00:00Z":null,sudoAvailable:true,dpkgAuditClean:true,dpkgAuditOutput:"",rebootRequired:false,
    packages:names.map(name => ({name,candidateVersion:"1.0.0",installedVersion:installed?"1.0.0":null}))}),
    refreshMetadata:async()=>{counts.refresh++;fresh=true;}, simulateInstall:async()=>{counts.simulate++;}, installPinned:async()=>{counts.install++;installed=true;}};
  const make = () => new SetupEngine({fsAdapter:x.f,processAdapter:r14Process,clock},createRegistry([r14Noop("S01"),createSystemStage(apt)]));
  return {x,counts,clock,apt,make,advance:(ms:number)=>{now+=ms;}};
}
function rehash(plan: InstallerPlan) {const {plan_hash,...payload}=plan;plan.plan_hash=createHash("sha256").update(stableStringify(payload)).digest("hex");}
test("A21-01 actual S02 stripped stage+operation gates cannot authorize APT", async () => {
  const q=await aptFixture(),e=q.make();assert.equal((await e.run("plan",{configPath:q.x.configPath})).exitCode,0);
  const p=JSON.parse(await fs.readFile(q.x.applyOptions.planPath,"utf8")) as InstallerPlan;
  for(const s of p.stages){s.required_gates=[];for(const op of s.operations)op.gate_ids=[];} rehash(p);await fs.writeFile(q.x.applyOptions.planPath,JSON.stringify(p));
  const applied=await e.run("apply",{...q.x.applyOptions,nonInteractive:true});assert.notEqual(applied.exitCode,0);assert.deepEqual(q.counts,{refresh:0,simulate:0,install:0});
});
test("A21-09 independently expired plan refuses even before APT approval checks",async()=>{
  const q=await aptFixture(),e=q.make();await q.x.planAndApprove(e);q.advance(31*60_000);
  assert.notEqual((await e.run("apply",q.x.applyOptions)).exitCode,0);assert.deepEqual(q.counts,{refresh:0,simulate:0,install:0});
});
for(const age of [31,-60]) test(`A21-09 synthetic gate-free age ${age} minutes cannot execute`,async()=>{
  const q=await aptFixture();let effects=0;const s=r14Noop("S02");s.dependencies=["S01"];
  s.observe=async()=>({stageId:"S02",status:effects?"verified":"planned",checks:{},versions:{},observedAt:q.clock.now().toISOString()});
  s.plan=()=>({stageId:"S02",optional:false,requiredCapabilities:[],requiredGates:[],operations:[{id:"age-effect",stageId:"S02",kind:"mutate",resourceId:"synthetic",risk:"low",gateIds:[],preconditions:[],sideEffects:["local counter"],timeoutSec:1,retryable:false}]});
  s.apply=async()=>{effects++;return [{operationId:"age-effect",stageId:"S02",resourceId:"synthetic",observedAt:q.clock.now().toISOString(),checks:{done:true},versions:{},artifacts:[]}];};
  const e=new SetupEngine({fsAdapter:q.x.f,processAdapter:r14Process,clock:q.clock},createRegistry([r14Noop("S01"),s]));
  await q.x.planAndApprove(e);q.advance(age*60_000);assert.notEqual((await e.run("apply",q.x.applyOptions)).exitCode,0);assert.equal(effects,0);
});
