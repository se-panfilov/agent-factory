from pathlib import Path
import hashlib,subprocess,os,tarfile,io,json
r=Path('/Users/splswrd/work/agent-factory');t=Path('/private/tmp/af-r21');o=r/'audit/evidence/q1a-r2-1-2026-10-25-local';env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(*a):return subprocess.check_output(['git',*a],cwd=r,env=env)
mfile=o/'tested-files.sha256';old=hashlib.sha256(mfile.read_bytes()).hexdigest();lines=[]
for line in mfile.read_text().splitlines():
 h,n=line.split('  ',1);lines.append(hashlib.sha256((r/n).read_bytes()).hexdigest()+'  '+n)
mfile.write_text('\n'.join(lines)+'\n');new=hashlib.sha256(mfile.read_bytes()).hexdigest()
p=r/'docs/audits/remediation-q1a-r2-1-2026-10-25.md';p.write_text(p.read_text().replace(old,new))
patch=git('diff','--binary','HEAD','--','setup')
for n in git('ls-files','--others','--exclude-standard','setup').decode().splitlines():
 result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=r,env=env,stdout=subprocess.PIPE);assert result.returncode==1;patch+=result.stdout
(o/'full-local.patch').write_bytes(patch);fixed=t/'fixed-final';fixed.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive','HEAD'))) as a:a.extractall(fixed,filter='data')
subprocess.run(['git','apply',str(o/'full-local.patch')],cwd=fixed,env=env,check=True)
for line in lines:
 h,n=line.split('  ',1);assert hashlib.sha256((fixed/n).read_bytes()).hexdigest()==h,n
(t/'pre-strict-type-reconstruction-before.json').write_bytes((t/'reconstruction-before.json').read_bytes());(t/'reconstruction-before.json').write_text(json.dumps({'match':True,'files':len(lines),'manifest_sha256':new,'base':git('rev-parse','HEAD').decode().strip()},indent=2)+'\n')
# Retain the previous full logs; only final-validation describes final source bytes.
(t/'pre-strict-type-validation').mkdir()
import shutil
for p in (t/'final-validation').iterdir():shutil.copy2(p,t/'pre-strict-type-validation'/p.name)
print(new)
