import subprocess,os,pathlib,hashlib,tarfile,io,json
root=pathlib.Path('/Users/splswrd/work/agent-factory');temp=pathlib.Path('/private/tmp/af-r16');out=root/'audit/evidence/q1a-r1-6-2026-10-25-local';out.mkdir(exist_ok=True)
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(*a):return subprocess.check_output(['git',*a],cwd=root,env=env)
names=sorted(set(git('ls-files','setup').decode().splitlines()+git('ls-files','--others','--exclude-standard','setup').decode().splitlines()));deleted=[n for n in names if not (root/n).exists()]
manifest=''.join(hashlib.sha256((root/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names if n not in deleted);(out/'tested-files.sha256').write_text(manifest);(out/'deletions.json').write_text(json.dumps(deleted)+'\n')
patch=git('diff','--binary','HEAD','--','setup')
for n in git('ls-files','--others','--exclude-standard','setup').decode().splitlines():
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],cwd=root,env=env,stdout=subprocess.PIPE);assert r.returncode==1;patch+=r.stdout
(out/'full-local.patch').write_bytes(patch)
copy=temp/'fixed';copy.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive','HEAD'))) as t:t.extractall(copy,filter='data')
subprocess.run(['git','apply',str(out/'full-local.patch')],cwd=copy,env=env,check=True)
for l in manifest.splitlines():
 h,n=l.split('  ',1);assert hashlib.sha256((copy/n).read_bytes()).hexdigest()==h,n
(temp/'reconstruction-before.json').write_text(json.dumps({'match':True,'files':len(names)-len(deleted),'manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest(),'base':git('rev-parse','HEAD').decode().strip()},indent=2)+'\n');print(len(names)-len(deleted))
