# Independent Q1A-R2.1.1 review

Reviewed commit: `117a71e3607659e97509b99c1662131c3970c112`.
Verdict: accept R21-F01/F02 locally; proceed to R2.2. Production OPEN.
Supplementary final-recovery continuation remains known-red with a verified explicit-review workaround.

Read `agent-factory-r211-audit-117a71e.ru.md`, then `copilot-q1a-r2-2-task.ru.md`.
No commits/push/branches/worktree/PR/index staging/merge/tag/release/deploy are authorized.

Contents:

- `incoming/`: complete unchanged extracted Copilot package, patches, manifest, inputs, original runners and logs.
- `evidence/identity-verification.json`: exact attachment/source identity and environment.
- `evidence/validation/`: independent 446-test/typecheck logs for exact master.
- `evidence/access-*`: original S03 red/green and genuine legacy transition matrices.
- `evidence/comparisons/`: initial comparison run; incomplete fixed-adapter output was rejected, not counted.
- `evidence/command-rerun/` and `comparisons-rerun/`: targeted diagnostics and complete successful 33/37/39 rerun.
- `evidence/recovery-*`: unchanged desired-red oracle and independently rerun measurements, both versions.
- `evidence/context-binding-probes.cjs`, `check-context-binding.py`, `context-*`: new R2.2 counterexamples and controls.
- `evidence/regression-baseline/`: meaningful regression-red test overlay on unchanged compiled baseline production.
- `evidence/source-diff.patch`: reviewed source/test/docs changes.
- `evidence/portable-replay/`: incomplete combined replay, including both failed comparison attempts; not a green validation run.
- `source/`: exact tested setup source/schema/docs/test inputs plus normative CONTRACT/AGENTS, without dist/dependencies.

Verify outer ZIP checksum, archive CRC and every entry in `SHA256SUMS` before use. Checksums establish
bytes, not semantic validity. The archive includes its audit and task copies verbatim.

Full replay requires Python3.12+, Node major24/npm, and a local clone with the recorded Git objects:
117a71e (published target), 6281df5 (actual S03 base), ca6d0b6 (historical R2 baseline), b888082
(historical command baseline). From this extracted package run:

```text
python3 evidence/reproduce-review.py --repo /absolute/local/clone --work /absolute/empty/temp-directory
```

It uses `git archive`/`git show` only, reconstructs base+patch, validates manifest against published
source, installs locked dependencies with lifecycle scripts disabled, runs tests and product oracles,
and checks source hashes afterwards. It never fetches or changes Git refs/index/checkout. Only npm
dependency downloads may need network. All filesystem effects are inside disposable fixtures/copies.

Expected outcomes for this exact version: S03 baseline 3/13 desired pass, fixed13/13, legacy13/13;
446 tests pass; frozen33/command37/R2checker39 pass; supplementary recovery has four desired failures
with zero replay and fresh-review workaround; context matrix is 2/5 desired pass on each version.
Reproduction success means these results were faithfully reproduced, not that all product requirements pass.
If any runner returns an empty/incomplete log, stop and retain it; never call that PASS.
In this review the combined replay is INCOMPLETE. Its first comparison attempt had only one
historical baseline-stage row. One explicit `--resume-prepared` after diagnosis rechecked and rebuilt
sources, preserved old logs and wrote comparisons separately; that attempt then stopped on missing
frozen C08 output. No further retry-until-green was performed. The original independent comparisons
in `evidence/comparisons-rerun/` did complete all 33/37/39 assertions, and independent recovery/context
measurements are available outside portable-replay. Do not conflate these with a successful combined
replay. Root cause remains unresolved (R211-O02); a small product-free FS diagnostic passed5/5 and
does not explain the missing outputs. The script fails closed and never fills in missing cases.

For future R2.2 changes run the context probes against the implementation and require
`check-context-binding.py LOG --expect fixed` to return0 with5/5. Schema/fixture adaptations must be
separately named and documented; freeze original inputs and preserve functional assertions. The
`observed-current` oracle is historical measurement only, never acceptance of a repair.

Real sudo/APT/systemd/SSH/UFW/Docker daemon, physical reboot/power loss, VM/VPS, credentials/OAuth,
model/provider calls, GitHub writes, releases and deployments were NOT RUN. Test launcher UID0
is an isolated reviewer environment; installer owner identity is injected UID1000. No root installer
deployment or Ubuntu qualification is claimed.
