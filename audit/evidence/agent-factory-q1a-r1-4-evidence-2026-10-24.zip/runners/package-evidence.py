#!/usr/bin/env python3
import pathlib,sys,zipfile,hashlib
source=pathlib.Path(sys.argv[1]).resolve(); output=pathlib.Path(sys.argv[2]).resolve()
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(source.rglob('*')):
  if not p.is_file(): continue
  info=zipfile.ZipInfo(str(p.relative_to(source)),(2026,10,24,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100644<<16
  z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print(hashlib.sha256(output.read_bytes()).hexdigest())
